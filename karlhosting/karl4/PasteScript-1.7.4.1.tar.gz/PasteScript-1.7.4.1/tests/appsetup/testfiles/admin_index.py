from projectname.sitepage import *

class index(SitePage):

    link_id = 'admin_index'

