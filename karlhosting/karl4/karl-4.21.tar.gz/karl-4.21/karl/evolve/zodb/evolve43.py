def evolve(site):
    """This used to add oobtree for followed topics to chatter
    """
