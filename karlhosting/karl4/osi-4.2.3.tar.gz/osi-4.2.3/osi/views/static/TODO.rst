Must Do
=======


Should Do
=========

- Switch from confirm -> modal

- Write some tests:wq


- Make "All KARL" functional

- Archive working JSON representations to better recover from errors

- Preview the number of matches server-side with Tres's URLs

- Allow is_staff and group filters


Would Be Nice
=============

- Find some way to let Nat backup the JSON

- grunt concat the files

- Unit tests

Once Shipping
==============

- Test mailing list support to make sure it isn't getting wiped

- Tell Nat to download JSON proactively
