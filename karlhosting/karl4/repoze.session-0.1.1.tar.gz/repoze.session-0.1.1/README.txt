==================
``repoze.session``
==================

An HTTP sessioning system for web applications, based on code from the
`<faster http://agendaless.com/Members/tseaver/software/faster/>`_
Zope 2 product.  ``repoze.session`` uses ZODB as its persistence
mechansism.

See the ``docs`` subdirectory for more documentation.

