=========================================================
ZODB3 - Meta release for ZODB, persistent, BTrees and ZEO
=========================================================

The ZODB3 distribution is a "meta" distribution that requires projects:
ZODB, persistent, BTrees and ZEO, which, in the past, were included in
the ZODB 3 project.

For more information on ZODB, persistent, BTrees, and ZEO, see the
respective project pages in PyPI:

- http://pypi.python.org/pypi/ZODB

- http://pypi.python.org/pypi/persistent

- http://pypi.python.org/pypi/BTrees

- http://pypi.python.org/pypi/ZEO

and http://zodb.org.

