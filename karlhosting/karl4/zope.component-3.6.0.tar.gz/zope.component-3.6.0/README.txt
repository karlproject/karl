*****************************
zope.component Package Readme
*****************************

This package represents the core of the Zope Component Architecture.
Together with the 'zope.interface' package, it provides facilities for
defining, registering and looking up components.

.. contents::
