.. _testing_module:

:mod:`pyramid.testing`
==========================

.. automodule:: pyramid.testing

  .. autofunction:: setUp

  .. autofunction:: tearDown

  .. autofunction:: cleanUp

  .. autoclass:: DummyResource
     :members:

  .. autoclass:: DummyRequest
     :members:

  .. autoclass:: DummyTemplateRenderer
     :members:



