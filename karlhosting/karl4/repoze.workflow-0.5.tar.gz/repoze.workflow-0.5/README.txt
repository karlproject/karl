repoze.workflow
===============

repoze.workflow is a state machine and associated configuration system
useful for workflow-like applications.  Refer to docs/index.rst or
`the online docs <http://docs.repoze.org/workflow>`_ for further
information.
