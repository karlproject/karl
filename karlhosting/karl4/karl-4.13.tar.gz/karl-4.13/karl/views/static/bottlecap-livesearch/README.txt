
Remaining parts of bottlecap, reduced to a miminal clean set of resources.
