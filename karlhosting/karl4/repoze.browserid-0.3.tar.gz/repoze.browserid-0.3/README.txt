repoze.browserid
================

Browser id middleware for WSGI.  Browser ids are cookies which
uniquely represent a user's browser, for use by sessioning libraries.

See `http://docs.repoze.org/browserid
<http://docs.repoze.org/repoze.browserid>`_ for documentation.

