Test runner and main()
======================

.. automodule :: nose.core
   :members:
