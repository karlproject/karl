import a

def test_a():
    a.a()
