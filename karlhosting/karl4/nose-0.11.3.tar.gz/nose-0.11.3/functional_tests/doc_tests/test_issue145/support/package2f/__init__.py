def setup():
    print 'package2f setup'
