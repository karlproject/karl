ZEO networking implemention based on asyncio to-dos
===================================================

First iteration, client only
----------------------------

- socketless tests for protocol and adapters

- Disconnect/reconnect strategy

- Integration with ClientStorage

Second iteration, server
------------------------

TBD after client release.

