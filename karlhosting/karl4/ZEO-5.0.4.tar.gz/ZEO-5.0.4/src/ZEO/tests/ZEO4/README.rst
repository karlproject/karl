======================
Copy of ZEO 4 server
======================

This copy was made by first converting the ZEO 4 server code to use
relative imports.  The code was tested with ZEO 4 before copying.  It
was unchanged aside from the relative imports.

The ZEO 4 server is used for tests if the ZEO4_SERVER environment
variable is set to a non-empty value.
