tinyMCE.addI18n('en.kaltura',{
kaltura_button_desc: "Insert/edit Kaltura video"
});
