
(function($){

module("karl-datetimepicker");

test("Create and destroy", function() {


    $('#datetime1').karldatetimepicker({
        });

    $('#datetime1').karldatetimepicker('destroy');

});


})(jQuery);

