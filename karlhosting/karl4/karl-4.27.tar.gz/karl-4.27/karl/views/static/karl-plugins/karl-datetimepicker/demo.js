
(function($){

    $(document).ready(function() {

        $('.datetime').karldatetimepicker({
        });

    });

})(jQuery);

