
$(document).ready(function() {

    // bind buttons
    $('#toolbar .karl-buttonset').karlbuttonset();

    // themeswitcher
    $('#switcher').themeswitcher();

});
