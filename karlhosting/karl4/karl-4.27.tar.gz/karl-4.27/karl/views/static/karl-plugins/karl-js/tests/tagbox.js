/*
 * tagbox unit tests
 */
(function($) {

module("karl: tagbox");

test('true', function() {

});

})(jQuery);