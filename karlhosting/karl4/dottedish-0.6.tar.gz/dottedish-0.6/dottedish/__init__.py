from dottedish.api import *
from dottedish import dotteddict, dottedlist
