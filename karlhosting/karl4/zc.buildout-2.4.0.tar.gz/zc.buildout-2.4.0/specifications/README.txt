This directory is (an experimental) place to manage Launchpad
specification bodies.  Files here are referenced (via svn.zope.org
URLs) from the buildout project specifications in Launchpad, 
https://features.launchpad.net/products/zc.buildout.
