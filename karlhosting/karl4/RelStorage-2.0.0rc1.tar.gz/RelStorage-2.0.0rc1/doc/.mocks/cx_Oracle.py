class OperationalError(Exception): pass
class InterfaceError(Exception): pass
class DatabaseError(Exception): pass
