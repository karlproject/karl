class MemcachedError(Exception): pass
