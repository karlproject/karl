See doc/developing.rst.
