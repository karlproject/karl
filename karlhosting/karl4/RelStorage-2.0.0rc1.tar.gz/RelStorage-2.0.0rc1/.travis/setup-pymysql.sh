pip install -U pymysql
`dirname $0`/mysql.sh
