pip install -U -e ".[mysql]"
`dirname $0`/mysql.sh
