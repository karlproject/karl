pip install -U pg8000
`dirname $0`/postgres.sh
