pip install -U -e ".[postgresql]"
`dirname $0`/postgres.sh
