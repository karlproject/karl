====
ZODB
====

Introduction
============

The ZODB  package provides a  set of tools  for using the  Zope Object
Database (ZODB).

Our primary development platforms are Linux and Mac OS X.  The test
suite should pass without error on these platforms and, hopefully,
Windows, although it can take a long time on Windows -- longer if you
use ZoneAlarm.

License
=======

ZODB is distributed under the Zope Public License, an OSI-approved
open source license.  Please see the LICENSE.txt file for terms and
conditions.

More information
================

See http://zodb.org/
