repoze.urchin README
====================

This package provides WSGI middleware for injecting the markup
required to use Google Analytics into web pages.

Please see docs/index.rst for detailed documentation.
