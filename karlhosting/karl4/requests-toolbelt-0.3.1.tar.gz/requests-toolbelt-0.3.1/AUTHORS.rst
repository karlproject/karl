Requests-toolbelt is written and maintained by Ian Cordasco, Cory Benfield and
various contributors:

Development Lead
````````````````

- Ian Cordasco

- Cory Benfield


Requests
````````

- Kenneth Reitz <me@kennethreitz.com> and various contributors


Urllib3
```````

- Andrey Petrov <andrey.petrov@shazow.net>


Patches and Suggestions
```````````````````````

- Jay De Lanoy <jay@delanoy.co>
