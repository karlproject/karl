import unittest

class TestField(unittest.TestCase):
    def _make_one(self, form):
        from formish.forms import Field as cls
        return cls('foo', DummyAttribute, form)

    def test_unicode_error(self):
        form = DummyForm()
        form.errors['foo'] = u"I\u2019m a cowboy."
        field = self._make_one(form)
        self.assertEqual(unicode(field.error), u"I\u2019m a cowboy.")

    def test_classes_with_unicode_error(self):
        form = DummyForm()
        form.errors['foo'] = u"I\u2019m a cowboy."
        field = self._make_one(form)
        self.assertEqual(field.classes, 'field foo_form-foo foo_class error')

class DummyForm(object):
    name = 'foo_form'

    def __init__(self):
        self.errors = {}
        self.item_data = {
            'widget': DummyWidget(),
        }

    def get_item_data(self, field, name, default=None):
        return self.item_data.get(name, default)

class DummyAttribute(object):
    validator = None

class DummyWidget(object):
    css_class = 'foo_class'
