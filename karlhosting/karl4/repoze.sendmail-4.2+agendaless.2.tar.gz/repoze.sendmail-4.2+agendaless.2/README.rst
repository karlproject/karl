`repoze.sendmail` README
========================

`repoze.sendmail` allows coupling the sending of email messages with a
transaction, using the Zope transaction manager.  This allows messages to
only be sent out when and if a transaction is committed, preventing users
from receiving notifications about events which may not have completed
successfully.

Please see `docs/index.rst` for complete documentation, or read the
docs online at http://docs.repoze.org/sendmail
