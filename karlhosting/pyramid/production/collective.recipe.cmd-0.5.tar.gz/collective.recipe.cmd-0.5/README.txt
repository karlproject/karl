.. contents::

.. Note to recipe author!
   ---------------------
   Update the following URLs to point to your:
   
   - code repository
   - bug tracker 
   - questions/comments feedback mail 
   (do not set a real mail, to avoid spams)

   Or remove it if not used.


