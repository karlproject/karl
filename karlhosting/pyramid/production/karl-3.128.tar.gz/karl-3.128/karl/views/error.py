def raise_error(context, request):
    raise Exception('Forced exception')
