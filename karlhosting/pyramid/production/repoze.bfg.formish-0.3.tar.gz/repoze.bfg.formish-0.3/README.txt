repoze.bfg.formish
==================

Bindings for the `formish <http://ish.io/projects/show/formish>`_ form
generation library with `repoze.bfg <http://bfg.repoze.org>`_,
including a set of `Chameleon <http://chameleon.repoze.org>`_
templates that implement formish widget renderers.

Please see `http://docs.repoze.org/repoze.bfg.formish
<http://docs.repoze.org/repoze.bfg.formish>`_ for documentation.



