#
# Data for the Eurasia offices
#
from zope.interface import implements

from karl.bootstrap.interfaces import IInitialOfficeData

from pyramid.security import Allow

from karl.security.policy import ADMINISTRATOR_PERMS
from karl.security.policy import GUEST_PERMS
from karl.security.policy import NO_INHERIT

navmenu_template = u"""\
<div>
  <div class="menu">
    <h3>About EF Network</h3>
    <ul class="nav">
      <li>
        <a href="/about-ef-network" target="" title="">About EF Network</a>
      </li>
      <li>
        <a href="/benefits-of-network-membership" target="" title="">Benefits of Network Membership</a>
      </li>
      <li>
        <a href="/partner-foundation-roles-and-relationships" target="" title="">Partner Foundation Roles and Relationships</a>
      </li>
      <li>
        <a href="/people" target="" title="">Network Directory</a>
      </li>
      <li class="submenu">
        <a target="" title="">Web Site Directory</a>
        <ul class="level2">
          <li>
            <a href="/offices/efca/about/web-site-directory" target="" title="">EFCA web sites</a>
          </li>
          <li>
            <a href="/offices/epf/about/web-site-directory" target="" title="">EPF web sites</a>
          </li>
          <li>
            <a href="/offices/eef/about/web-site-directory" target="" title="">EEF web sites</a>
          </li>
          <li>
            <a href="/offices/fne/about/web-site-directory" target="" title="">FNE web sites</a>
          </li>
          <li>
            <a href="/offices/ef/about/web-site-directory" target="" title="">EF web sites</a>
          </li>
        </ul>
      </li>
    </ul>
  </div>

  <div class="menu">
    <h3>About %(org_upper)s</h3>
    <ul class="nav">
      <li>
        <a href="/offices/%(org)s/about/about-%(org)s" target="" title="">About %(org_upper)s</a>
      </li>
      <li>
        <a href="/offices/%(org)s/about/basic-office-info" target="" title="">Basic Office Info</a>
      </li>
    </ul>
  </div>

  <div class="menu">
    <h3>Resources</h3>
    <ul class="nav">
      <li class="submenu">
        <a href="/offices/%(org)s/referencemanuals" target="" title="">Policy, Forms, &amp; Templates</a>
        <ul class="level2">
          <li>
            <a href="/offices/%(org)s/referencemanuals/development" target="" title="">Development</a>
          </li>
          <li>
            <a href="/offices/%(org)s/referencemanuals/communications" target="" title="">Communications</a>
          </li>
          <li>
            <a href="/offices/%(org)s/referencemanuals/programs" target="" title="">Programs</a>
          </li>
          <li>
            <a href="/offices/%(org)s/referencemanuals/project-management" target="" title="">Project Management</a>
          </li>
          <li>
            <a href="/offices/%(org)s/referencemanuals/grants-management" target="" title="">Grants Management</a>
          </li>
          <li>
            <a href="/offices/%(org)s/referencemanuals/evaluation" target="" title="">Measurement &amp; Evaluation</a>
          </li>
          <li>
            <a href="/offices/%(org)s/referencemanuals/travel" target="" title="">Travel and Expenses</a>
          </li>
          <li>
            <a href="/offices/%(org)s/referencemanuals/general-accounting" target="" title="">General Accounting</a>
          </li>
          <li>
            <a href="/offices/%(org)s/referencemanuals/hr" target="" title="">HR &amp; Office Admin</a>
          </li>
          <li>
            <a href="/offices/%(org)s/referencemanuals/information-technology" target="" title="">Computers and IT</a>
          </li>
          <li>
            <a href="/offices/%(org)s/referencemanuals/presidents-office" target="" title="">President's Office</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="/offices/%(org)s/calendars" target="" title="">Calendars</a>
      </li>
      <li>
        <a href="/offices/%(org)s/forums" target="" title="">Message Boards</a>
      </li>
      <li>
        <a href="/offices/%(org)s/subscriptions" target="" title="">Subscriptions</a>
      </li>
      <li>
        <a href="/offices/%(org)s/help/other-helpful-tools" target="" title="">Other Helpful Tools</a>
      </li>
    </ul>
  </div>

  <div class="menu">
    <h3>Help Desk</h3>
    <ul class="nav">
      <li>
        <a href="/offices/%(org)s/help/accessing-voicemail" target="" title="">Check your Work Voicemail</a>
      </li>
      <li>
        <a href="http://mail.eurasia.org/exchange" target="" title="">Check your Work Email</a>
      </li>
      <li>
        <a href="/communities/user-manual" target="" title="">User Manual</a>
      </li>
    </ul>
  </div>
</div>
"""



sample_feature = """\
<div>
  <div class="teaser">
    <a href="http://www.eef.org.ua/en/">
      <img src="/static/images/sample_feature.jpg" />
    </a>
  </div>
  <div class="visualClear"></div>
  <div class="featureLinks">
    <p>
      <a href="http://www.eef.org.ua/en/">EEF, Slavutich Carlsberg Group Revamp Senior Centers in Zaporizhzhia</a>
    </p>
    <p>
      <a href="http://www.efnetwork.org/communities/eurasia-foundation-network-proposals-index">Eurasia Foundation's Network Proposal Index</a>
    </p>
    <p>
      <a href="http://www.eef.org.ua/main/en/news/top.htm">EEF's Liakh Meets HRH The Prince of Wales</a>
    </p>
    <p>
      <a href="http://www.efnetwork.org/communities/russia-us-civil-society-summit/wiki/civil-society-summit-in-the-news">Civil Society Summit In The News</a>
    </p>
    <p>
      <a href="http://www.youtube.com/watch?v=zmKn254nDW8">View video clip of President Obama at Summit and Interview with Horton Beebe-Center on Russia Today</a>
    </p>
  </div>
</div>
"""

eef_forums = [
    {'id': 'eef-events', 'title': 'East Europe Foundation Events' },
    {'id': 'eef-news', 'title': 'East Europe Foundation News' },
    {'id': 'eef-personals', 'title': 'East Europe Foundation Personals' },
    ]

efca_forums = [
    {'id': 'efca-events',
     'title': 'Eurasia Foundation of Central Asia Events' },
    {'id': 'efca-news',
     'title': 'Eurasia Foundation of Central Asia News' },
    {'id': 'efca-personals',
     'title': 'Eurasia Foundation of Central Asia Personals' },
]

ef_forums = [
    {'id': 'ef-events', 'title': 'Eurasia Foundation Events' },
    {'id': 'ef-news', 'title': 'Eurasia Foundation News' },
    {'id': 'ef-personals', 'title': 'Eurasia Foundation Personals' },
    ]

epf_forums = [
    {'id': 'epf-events', 'title': 'Eurasia Partnership Foundation Events' },
    {'id': 'epf-news', 'title': 'Eurasia Partnership Foundation News' },
    {'id': 'epf-personals',
     'title': 'Eurasia Partnership Foundation Personals' },
    ]

fne_forums = [
    {'id': 'fne-events', 'title': 'New Eurasia Foundation Events' },
    {'id': 'fne-news', 'title': 'New Eurasia Foundation News' },
    {'id': 'fne-personals', 'title': 'New Eurasia Foundation Personals' },
    ]

middle_portlets = ['/offices/files/network-news/',
                   '/offices/files/network-events/',
                   ]

class EurasiaOfficeData(object):
    implements(IInitialOfficeData)

    title = 'Intranet'
    feature = sample_feature
    offices_acl = [
        (Allow, 'group.KarlAdmin', ADMINISTRATOR_PERMS),
        (Allow, 'group.KarlStaff', GUEST_PERMS),
        NO_INHERIT,
    ]

    offices = [
        {'id': 'eef',
         'title': 'East Europe Foundation',
         'address': '55 Velyka Vasylkivska, 3rd floor',
         'city': 'Kyiv',
         'state': '',
         'country': 'Ukraine',
         'zipcode': '03680',
         'telephone': '38-044-200-38-24/25/26/27',
         'middle_portlets': middle_portlets,
         'right_portlets': ['/offices/eef/forums/eef-news'],
         'forums': eef_forums,
         'navmenu': navmenu_template % {'org': 'eef', 'org_upper': 'EEF'},
         },
        {'id': 'efca',
         'title': 'Eurasia Foundation of Central Asia',
         'address': '',
         'city': '',
         'state': '',
         'country': '',
         'zipcode': '',
         'telephone': '',
         'middle_portlets': middle_portlets,
         'right_portlets': ['/offices/efca/forums/efca-news'],
         'forums': efca_forums,
         'navmenu': navmenu_template % {'org': 'efca', 'org_upper': 'EFCA'},
         },
        {'id': 'ef',
         'title': 'Eurasia Foundation',
         'address': '',
         'city': '',
         'state': '',
         'country': '',
         'zipcode': '',
         'telephone': '',
         'middle_portlets': middle_portlets,
         'right_portlets': ['/offices/ef/forums/ef-news'],
         'forums': ef_forums,
         'navmenu': navmenu_template % {'org': 'ef', 'org_upper': 'EF'},
         },
        {'id': 'epf',
         'title': 'Eurasia Partnership Foundation',
         'address': '',
         'city': '',
         'state': '',
         'country': '',
         'zipcode': '',
         'telephone': '',
         'middle_portlets': middle_portlets,
         'right_portlets': ['/offices/epf/forums/epf-news'],
         'forums': epf_forums,
         'navmenu': navmenu_template % {'org': 'epf', 'org_upper': 'EPF'},
         },
        {'id': 'fne',
         'title': 'New Eurasia Foundation',
         'address': '',
         'city': '',
         'state': '',
         'country': '',
         'zipcode': '',
         'telephone': '',
         'middle_portlets': middle_portlets,
         'right_portlets': ['/offices/fne/forums/fne-news'],
         'forums': fne_forums,
         'navmenu': navmenu_template % {'org': 'fne', 'org_upper': 'FNE'},
         },
    ]

    pages = []
