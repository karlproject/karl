from karl.security.workflow import reset_security_workflow
from pyramid.traversal import traverse
from pyramid.traversal import model_path

exceptions = ['/offices']

def evolve(context):
    for path in exceptions:
        d = traverse(context, path)
        ob = d['context']
        if model_path(ob) == path:
            if hasattr(ob, '__acl__'):
                ob.__custom_acl__ = ob.__acl__
    reset_security_workflow(context)
