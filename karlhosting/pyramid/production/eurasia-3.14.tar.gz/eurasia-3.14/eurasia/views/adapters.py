
from karl.content.interfaces import ICalendarEvent
from karl.content.interfaces import IForum
from karl.content.interfaces import IReferencesFolder
from karl.content.views.interfaces import INetworkEventsMarker
from karl.content.views.interfaces import INetworkNewsMarker
from karl.models.interfaces import IIntranet
from karl.models.interfaces import IIntranets
from karl.models.interfaces import ISite
from karl.models.interfaces import IToolFactory
from karl.views import site
from karl.views.interfaces import IFooter
from karl.views.interfaces import ILayoutProvider
from karl.views.interfaces import IToolAddables
from os.path import join
from pyramid.renderers import get_renderer
from pyramid.renderers import render
from pyramid.path import package_path
from pyramid.traversal import find_interface
from repoze.lemonade.listitem import get_listitems
from zope.interface import implements

class ToolAddables(object):
    """ Site-specific policies for adding tools to a community """
    implements(IToolAddables)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    def __call__(self):
        """ Modify the default list of what can go in a community """

        # Find out if we are adding this community from somewhere
        # inside the "intranets" side
        intranets = find_interface(self.context, IIntranets)
        is_site = ISite.providedBy(self.context)

        _tool_list = []
        intranets_block = ['wiki', 'blog']
        communities_block = ['intranets', 'forums']
        for toolinfo in get_listitems(IToolFactory):
            if intranets or is_site:
                if toolinfo['name'] not in intranets_block:
                    _tool_list.append(toolinfo)
            else:
                if toolinfo['name'] not in communities_block:
                    _tool_list.append(toolinfo)

        return _tool_list


class LayoutProvider(object):
    """ Site policy on which o-wrap to choose from for a context"""
    implements(ILayoutProvider)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    @property
    def community_layout(self):
        package_dir = package_path(site)
        template_fn = join(package_dir, 'templates', 'community_layout.pt')
        return get_renderer(template_fn).implementation()

    @property
    def generic_layout(self):
        package_dir = package_path(site)
        template_fn = join(package_dir, 'templates', 'generic_layout.pt')
        return get_renderer(template_fn).implementation()

    @property
    def intranet_layout(self):
        layout = get_renderer('templates/intranet_layout.pt').implementation()
        intranet = find_interface(self.context, IIntranet)
        if intranet:
            layout.navigation = intranet.navigation
        return layout

    def __call__(self, default=None):
        # The layouts are by identifier, e.g. layout='community'

        # A series of tests, in order of precedence.
        layout = None
        if default is not None:
            layout = getattr(self, default+'_layout')
        intranet = find_interface(self.context, IIntranet)

        # Group a series of intranet-oriented decisions
        if intranet:
            # First, when under an intranet, OSI wants forums to get
            # the generic layout.
            if find_interface(self.context, IForum):
                layout = getattr(self, 'generic_layout')

            # Now for an intranet.  Everything gets the two-column
            # view except the intranet home page, which gets the 3
            # column treatment.
            else:
                layout = getattr(self, 'intranet_layout')

        elif find_interface(self.context, IIntranets):
            if find_interface(self.context, IForum):
                layout = getattr(self, 'generic_layout')
            elif ICalendarEvent.providedBy(self.context):
                layout = getattr(self, 'generic_layout')
            elif INetworkNewsMarker.providedBy(self.context):
                layout = getattr(self, 'generic_layout')
            elif find_interface(self.context, IReferencesFolder):
                layout = getattr(self, 'generic_layout')
            elif INetworkEventsMarker.providedBy(self.context):
                layout = getattr(self, 'generic_layout')

        return layout

class EurasiaFooter(object):
    """ Multi-adapter for Eurasia-specific page footer.
    """
    implements(IFooter)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    def __call__(self, api):
        return render(
            'templates/footer.pt',
            dict(api=api),
            request=self.request,
            )
