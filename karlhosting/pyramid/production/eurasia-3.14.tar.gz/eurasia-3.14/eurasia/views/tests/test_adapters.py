
import unittest

from zope.interface import implements
from zope.interface import alsoProvides
from pyramid import testing

from karl.content.interfaces import ICommunityFolder
from karl.models.interfaces import IIntranets

class TestToolAddables(unittest.TestCase):
    def setUp(self):
        testing.cleanUp()

    def tearDown(self):
        testing.cleanUp()

    def _getTargetClass(self):
        from eurasia.views.adapters import ToolAddables
        return ToolAddables

    def _register(self):
        from repoze.lemonade.testing import registerListItem
        from karl.models.interfaces import IToolFactory
        tool_factory = DummyToolFactory(present=True)
        registerListItem(IToolFactory, tool_factory, 'blog')
        registerListItem(IToolFactory, tool_factory, 'wiki')
        registerListItem(IToolFactory, tool_factory, 'calendar')
        registerListItem(IToolFactory, tool_factory, 'files')
        registerListItem(IToolFactory, tool_factory, 'forums')
        registerListItem(IToolFactory, tool_factory, 'intranets')

    def _makeOne(self, context, request):
        return self._getTargetClass()(context, request)

    def test_class_conforms_to_IToolAddables(self):
        from zope.interface.verify import verifyClass
        from karl.views.interfaces import IToolAddables
        verifyClass(IToolAddables, self._getTargetClass())

    def test_tool_list_site(self):
        from karl.models.interfaces import ISite
        from zope.interface import alsoProvides
        self._register()
        context = testing.DummyModel()
        alsoProvides(context, ISite)
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        self.assertEqual(len(adapter()), 4)

    def test_tool_list_intranets(self):
        from karl.models.interfaces import IIntranets
        from zope.interface import alsoProvides
        self._register()
        intranets = testing.DummyModel()
        alsoProvides(intranets, IIntranets)
        context = testing.DummyModel()
        intranets['folder'] = context
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        self.assertEqual(len(adapter()), 4)

    def test_tool_list_communities(self):
        from karl.content.interfaces import ICommunityFolder
        from zope.interface import alsoProvides
        self._register()
        context = testing.DummyModel()
        alsoProvides(context, ICommunityFolder)
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        self.assertEqual(len(adapter()), 4)

class TestLayoutProvider(unittest.TestCase):
    def setUp(self):
        testing.cleanUp()

    def tearDown(self):
        testing.cleanUp()

    def _getTargetClass(self):
        from eurasia.views.adapters import LayoutProvider
        return LayoutProvider

    def _makeOne(self, context, request):
        return self._getTargetClass()(context, request)

    def test_class_conforms_to_ILayoutProvider(self):
        from zope.interface.verify import verifyClass
        from karl.views.interfaces import ILayoutProvider
        verifyClass(ILayoutProvider, self._getTargetClass())

    def test_unknown_layout(self):
        # No interface on context, no default layout passed in
        context = testing.DummyModel()
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        layout = adapter()
        self.assertEqual(layout, None)

    def test_default_is_community(self):
        # No interface on context, pass in community as choice
        context = testing.DummyModel()
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        layout = adapter('community')
        self.assert_('community_layout.pt' in layout.filename)

    def test_default_is_generic(self):
        # No interface on context, pass in community as choice
        context = testing.DummyModel()
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        layout = adapter('generic')
        self.assert_('generic_layout.pt' in layout.filename)

    def test_default_is_intranet(self):
        context = testing.DummyModel()
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        layout = adapter('intranet')
        self.assert_('intranet_layout.pt' in layout.filename)

    def test_forums_outside_intranet(self):
        from karl.content.interfaces import IForum
        from zope.interface import alsoProvides
        context = testing.DummyModel()
        alsoProvides(context, IForum)
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        # The karl.content.views.forums code will ask for community
        # layout (to be generic outside an intranet).  In this test,
        # we are NOT inside an intranet, causing the intranet policy (use
        # generic layout) NOT to be triggered.
        layout = adapter('community')
        self.assert_('community_layout.pt' in layout.filename)

    def test_forums_inside_intranet(self):
        from karl.content.interfaces import IForum
        from karl.models.interfaces import IIntranet
        from zope.interface import alsoProvides
        context = testing.DummyModel()
        alsoProvides(context, IForum)
        alsoProvides(context, IIntranet)
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        # The karl.content.views.forums code will ask for community
        # layout (to be generic outside an intranet), but the intranet
        # policy will impose a different o-wrap because we are in an
        # intranet.
        layout = adapter('community')
        self.assert_('generic_layout.pt' in layout.filename)

    def test_calendarevent_in_networkevents(self):
        # A "network event" is really a calendar event.  It exists at
        # the /offices/network-events level.
        from karl.content.interfaces import ICalendarEvent
        from karl.models.interfaces import IIntranets
        from zope.interface import alsoProvides
        context = testing.DummyModel()
        alsoProvides(context, ICalendarEvent)
        alsoProvides(context, IIntranets)
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        layout = adapter('community')
        self.assert_('generic_layout.pt' in layout.filename)

    def test_network_events(self):
        # A "network event" is really a calendar event.  It exists at
        # the /offices/network-events level.
        from karl.content.views.interfaces import INetworkEventsMarker
        from karl.models.interfaces import IIntranets
        from zope.interface import alsoProvides
        context = testing.DummyModel()
        alsoProvides(context, INetworkEventsMarker)
        alsoProvides(context, IIntranets)
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        layout = adapter('community')
        self.assert_('generic_layout.pt' in layout.filename)

class DummyIntranets(testing.DummyModel):
    title = 'dummyintranets'
    implements(IIntranets)

class DummyFolder(testing.DummyModel):
    title = 'dummyfolder'
    implements(ICommunityFolder)

class DummyToolFactory:
    def __init__(self, present=False):
        self.present = present

    def add(self, context, request):
        self.added = True

    def remove(self, context, request):
        self.removed = True

    def is_present(self, context, request):
        return self.present
