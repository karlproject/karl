/**
* KARL ux2 core resource composition
* You have to use juicer to produce a minified resource based on this file
* You cannot use this file as a development resource
*
*     @depends jquery-ui-1.9m5.min.js
*     @depends bootstrap-dropdown.js
*     @depends bootstrap-modal.js
*     @depends bootstrap-tooltip.js
*     @depends bootstrap-popover.js
*     @depends mustache-0.3.0.js
*     @depends ../plugins/popper-livesearch/bc-core/jquery.cookie.js
*     @depends ../plugins/popper-livesearch/bc-core/jquery.ajaxmanager-3.0.7.js
*     @depends ../plugins/popper-livesearch/bc-core/jquery.caret-1.0.2.min.js
*     @depends ../l10n/globalize.js
*     @depends ../l10n/globalize.cultures.js
*     @depends ../l10n/globalize.actions.js
*     @depends ../../jquery-plugins/jquery.timeago.js
*     @depends ../../jquery-ui/jquery.ui.selectmenu.js
*
*/

