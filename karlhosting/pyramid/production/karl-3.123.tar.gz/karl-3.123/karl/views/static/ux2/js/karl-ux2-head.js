/**
* KARL ux2 head resource composition
* You have to use juicer to produce a minified resource based on this file
* You cannot use this file as a development resource
*
*     @depends respond-1.2.0-dev.src.js
*     @depends jquery-1.7.1.min.js
*     @depends modernizr-2.0.6.min.js
*     @depends ios-orientationchange-fix.js
*
*     @ NOT depends ../google/jsapi.js
*
*/

