/**
* KARL ux2 legacy resource composition
* You have to use juicer to produce a minified resource based on this file
* You cannot use this file as a development resource
*
*     @depends ../../jquery-ui/grid/ui/ui.grid.js
*     @depends ../..//jquery-ui/grid/ui/ui.gridmodel.js
*     @depends ../../jquery-ui/autobox2/jquery.templating.js
*     @depends ../../jquery-ui/autobox2/jquery.ui.autobox.ext.js
*     @depends ../../jquery-ui/autobox2/jquery.ui.autobox.js
*     @depends ../../karl-plugins/karl-multistatusbox/karl.multistatusbox.js
*     @depends ../../karl-plugins/karl-captionedimage/karl.captionedimage.js
*     @depends ../../karl-plugins/karl-buttonset/karl.buttonset.js
*     @depends ../../jquery-plugins/jquery.scrollTo.src.js
*     @depends ../../karl.js
*
*/

