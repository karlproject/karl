.. _pyramid_zodbconn_api:

:mod:`pyramid_zodbconn` API
---------------------------

.. automodule:: pyramid_zodbconn

.. autofunction:: includeme

.. autofunction:: get_connection



