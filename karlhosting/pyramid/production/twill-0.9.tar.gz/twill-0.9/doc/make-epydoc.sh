#! /bin/bash
epydoc --docformat restructuredtext --no-private -n twill -o ./epydoc-html/ ../twill/
