#! /usr/bin/env bash
darcs dist -d twill-latest-`date +%Y-%m-%d`
