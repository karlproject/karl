To use the twill script generator for maxq,

 1. get the maxq source from maxq.tigris.org;

 2. copy TwillScriptGenerator.java into the java/com/bitmechanic/maxq/generator
    directory under the maxq source;

 3. run 'ant' to recompile maxq;

 4. add "com.bitmechanic.maxq.generator.TwillScriptGenerator" into the
    conf/maxq.properties file;

 5. run bin/maxq.

Please let me know if you run into any problems.

--titus

titus@caltech.edu
