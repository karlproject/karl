twill: a simple scripting language for Web browsing
===================================================

twill is a simple scripting language intended for programmatic or
automated browsing of Web sites.

Documentation is available in the release package under
doc/index.txt or doc/index.html.

The latest release as well as all documentation is always online at
http://twill.idyll.org/.  You can also find
information on mailing lists, bug fixes, and new releases there.

twill is Copyright (C) 2005, 2006, 2007 by C. Titus Brown, and is
available for use, modification, and distribution under the MIT
license.

Contact titus@caltech.edu with questions or comments.
