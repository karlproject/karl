# scripts dir
