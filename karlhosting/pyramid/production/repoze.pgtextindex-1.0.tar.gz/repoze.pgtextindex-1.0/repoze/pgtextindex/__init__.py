# API
from repoze.pgtextindex.index import PGTextIndex
