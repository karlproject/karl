formish.forms
=============

.. automodule:: formish.forms
    :members: Form, Action, Field, Group, Sequence
    :undoc-members:
    :show-inheritance:

