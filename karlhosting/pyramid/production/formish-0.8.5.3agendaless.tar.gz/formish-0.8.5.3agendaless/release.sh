rm -rf build
rm -rf dist
python setup.py bdist_egg sdist upload -s -i 43DA9303
