sample README
