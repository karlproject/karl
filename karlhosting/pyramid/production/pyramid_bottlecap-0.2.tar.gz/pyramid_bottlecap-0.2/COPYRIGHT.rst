Copyright (c) 2011 Agendaless Consulting and Contributors.
(http://www.agendaless.com), All Rights Reserved