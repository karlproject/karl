/**
* Bottlecap bc-core resource composition
* You have to use juicer to produce a minified resource based on this file
* You cannot use this file as a development resource
*
*
* bc-core: 
*     @depends ../jquery.cookie.js
*     @depends ../jquery.ajaxmanager-3.0.7.js
*     @depends ../jquery.caret-1.0.2.min.js
*     @depends ../jquery.timeago-0.9.3.js
*
*   
*
*/

