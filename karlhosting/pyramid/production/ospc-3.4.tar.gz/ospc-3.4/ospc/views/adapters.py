
from karl.utils import find_site
from karl.views.interfaces import IFooter
from karl.views.interfaces import IInvitationBoilerplate
from pyramid.chameleon_zpt import render_template
from zope.interface import implements

class InvitationBoilerplate(object):
    """ Policy for where to get terms of service and privacy statement"""
    implements(IInvitationBoilerplate)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    @property
    def terms_and_conditions(self):
        site = find_site(self.context)
        legal = site.get('legal')
        if not legal:
            return u"<p>No terms of service document found</p>"
        return legal.text

    @property
    def privacy_statement(self):
        # no privacy statement desired
        return ''

def community_folder_addables(context, request):
    def get_addables():
        return [
            ('Add Folder', 'add_folder.html'),
            ('Add File', 'add_file.html')
            ]
    return get_addables


class OSPCFooter(object):
    """ Multi-adapter for OSPC-specific page footer.
    """
    implements(IFooter)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    def __call__(self, api):
        return render_template(
            'templates/footer.pt',
            api=api,
            )
