__version__ = '3.2'

import os
from setuptools import setup, find_packages

here = os.path.abspath(os.path.dirname(__file__))
try:
    README = open(os.path.join(here, 'README.txt')).read()
except IOError:
    README = ''

requires = [
    'setuptools',
    'karl',
    ]

setup(name='gcfe',
      version=__version__,
      description='GCFE KARL customizations',
      long_description=README,
      classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Programming Language :: Python",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
        "Topic :: Internet :: WWW/HTTP :: WSGI",
        ],
      keywords='web wsgi zope karl',
      author="Open Society Institute",
      author_email="osi-dev@lists.palladion.com",
      url="http://launchpad.net/~teamkarl",
      license="GPL",
      packages=find_packages(),
      include_package_data=True,
      zip_safe=False,
      install_requires = requires,
      tests_require = requires,
      test_suite="nose.collector",
      entry_points = """
        [console_scripts]
        debug = karl.scripts.debug:main
        mailin = karl.scripts.mailin:main
        mailin2 = karl.scripts.mailin:main2
        reindex_catalog = karl.scripts.reindex_catalog:main
        digest = karl.scripts.digest:main
        peopleconf = karl.scripts.peopleconf:main
        adduser = karl.scripts.adduser:main
        """
)

