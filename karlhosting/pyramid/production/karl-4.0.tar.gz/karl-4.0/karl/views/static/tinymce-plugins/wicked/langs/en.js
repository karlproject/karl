// UK lang variables
tinyMCE.addI18n('en.wicked',{
    addwicked_desc : 'Add Wiki link',
    delwicked_desc : 'Remove Wiki link'
});
