from setuptools import setup

__version__ = '0.1'

setup(
    version=__version__,
    name='admin5'
)