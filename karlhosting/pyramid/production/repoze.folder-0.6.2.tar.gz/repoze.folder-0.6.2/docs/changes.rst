:mod:`repoze.folder` Change History
===================================

.. include:: ../CHANGES.txt
