from karl.models.interfaces import ICatalogSearch
from karl.models.interfaces import IProfile
from oxfam.models import Profile

def evolve(context):
    search = ICatalogSearch(context)
    cnt, docids, resolver = search(interfaces=[IProfile],
                                   sort_index='name')
    before = set([type(x) for x in context['profiles'].values()])
    for i, profile in enumerate([resolver(x) for x in docids]):
        if not isinstance(profile, Profile):
            parent = profile.__parent__
            name = profile.__name__
            log_name = profile.__name__.encode('ascii', 'replace')
            print 'Converting profile: [%08d of %08d] %s' % (i, cnt, log_name)
            newp = Profile(
                 profile.firstname,
                 profile.lastname,
                 profile.email,
                 profile.phone,
                 profile.extension,
                 profile.fax,
                 profile.department,
                 profile.position,
                 profile.organization,
                 profile.location,
                 profile.country,
                 profile.websites,
                 profile.languages,
                 profile.office,
                 profile.room_no,
                 profile.biography,
                 profile.date_format,
                 profile.data,
                 profile.home_path,
                 getattr(profile, 'preferred_communities', None),
                 )
            newp._alert_prefs.update(profile._alert_prefs)
            newp._pending_alerts.extend(profile._pending_alerts)
            newp.categories.update(profile.categories)
            newp.password_reset_key = profile.password_reset_key
            newp.password_reset_time = profile.password_reset_time
            newp.last_login_time = profile.last_login_time
            newp.last_chatter_query = profile.last_chatter_query
            newp.__acl__ = profile.__acl__
            newp.created = profile.created
            newp.modified = profile.modified
            newp.security_state = profile.security_state
            #newp.docid = profile.docid
            newp.employee_id = ''
            newp.job_title = ''
            newp.team = ''
            newp.division = ''
            newp.manager = ''
            newp.business_mobile_phone = ''
            newp.skype_name = ''
            newp.office_address = ''
            del parent[name]
            parent[name] = newp
