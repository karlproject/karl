
def evolve(site):
    """
    No longer needed.
    """