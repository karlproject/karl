#!/bin/bash
#tsuite=${1:-karl3 security offices calendar wiki}

# Make sure we are in the right directory
#cd ../twilltests

# Use correct Flunc with a PYTHONPATH to pick up karlcommands
#echo Running tsuite: $tsuite
#PYTHONPATH=. ../../../bin/flunc --config=karl3.conf $tsuite
echo "Use with a testname "
echo "To run all tests, use command: ./runtests.sh all"
echo "To run just one test, use with name of test, command: ./runtests.sh calendar"
echo "Running tsuite: " "$@"
../../../bin/flunc "$@"
