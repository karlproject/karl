.. _glossary:

Glossary
========

.. glossary::
   :sorted:

   Javascript
      `JavaScript <http://tools.ietf.org/html/rfc4329>`_ is an implementation
      of the `ECMAScript <http://www.ecmascript.org/>`_ language
      standard.
