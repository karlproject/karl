
/**
* bottlecap TAIL (end of BODY) resource composition
* You have to use juicer to produce a minified resource based on this file
* You cannot use this file as a development resource
*
*
* TAIL (end of BODY) resources:
*     @depends 0/mustache-0.3.0.js
*     @depends ../jquery-ui/1.9m5/ui/jquery.ui.widget.js
*
*/
