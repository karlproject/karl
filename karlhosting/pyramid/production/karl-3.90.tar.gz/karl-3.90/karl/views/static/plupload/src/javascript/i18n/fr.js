// .po file like language pack
plupload.addI18n({
    'Select files' : 'Sélectionner les fichiers',
    'Add files to the upload queue and click the start button.' : 'Ajouter des fichiers à la file et appuyer sur le bouton démarrer.',
    'Filename' : 'Nom de fichier',
    'Status' : 'Status',
    'Size' : 'Taille',
    'Add Files' : 'Ajouter fichiers',
    'Stop current upload' : 'Arrêter téléversement',
    'Start Upload' : 'Démarrer téléversement',
    'Drag files here.' : 'Déposer les fichiers ici.'
});