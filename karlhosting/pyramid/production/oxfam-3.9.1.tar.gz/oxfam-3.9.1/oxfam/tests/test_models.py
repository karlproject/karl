import unittest

class ProfileTests(unittest.TestCase):

    def _getTargetClass(self):
        from oxfam.models import Profile
        return Profile

    def _makeOne(self):
        return self._getTargetClass()()

    def test_class_conforms_to_IProfile(self):
        from zope.interface.verify import verifyClass
        from oxfam.interfaces import IProfile
        verifyClass(IProfile, self._getTargetClass())

    def test_instance_conforms_to_IProfile(self):
        from zope.interface.verify import verifyObject
        from oxfam.interfaces import IProfile
        verifyObject(IProfile, self._makeOne())
