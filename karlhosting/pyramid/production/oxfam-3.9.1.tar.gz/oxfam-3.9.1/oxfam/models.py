from zope.interface import implements

from karl.models.profile import Profile as KarlProfile
from oxfam.interfaces import IProfile

class Profile(KarlProfile):
    implements(IProfile)
    employee_id = job_title = team = division = manager = ''
    business_mobile_phone = skype_name = office_address = ''

    def __init__(self,
                 firstname = '',
                 lastname = '',
                 email = '',
                 phone = '',
                 extension = '',
                 fax = '',
                 department = '',
                 position = '',
                 organization = '',
                 location = '',
                 country = '',
                 websites = None,
                 languages = '',
                 office='',
                 room_no='',
                 biography='',
                 date_format=None,
                 data=None,
                 home_path=None,
                 preferred_communities = None,
                 # Oxfam-specific fields
                 employee_id = '',
                 job_title = '',
                 team = '',
                 division = '',
                 manager = '',
                 business_mobile_phone = '',
                 skype_name = '',
                 office_address = '',
                ):
        super(Profile, self).__init__(
                 firstname,
                 lastname,
                 email,
                 phone,
                 extension,
                 fax,
                 department,
                 position,
                 organization,
                 location,
                 country,
                 websites,
                 languages,
                 office,
                 room_no,
                 biography,
                 date_format,
                 data,
                 home_path,
                 preferred_communities,
                )
        self.employee_id = employee_id
        self.job_title = job_title
        self.team = team
        self.division = division
        self.manager = manager
        self.business_mobile_phone = business_mobile_phone
        self.skype_name = skype_name
        self.office_address = office_address

