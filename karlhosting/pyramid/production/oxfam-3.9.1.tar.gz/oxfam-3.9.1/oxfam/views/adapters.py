from pyramid.renderers import render
from zope.interface import implementer
from zope.interface import implements

from karl.utils import find_site
from karl.utilities.image import thumb_url
from karl.views.adapters import livesearch_dict
from karl.views.interfaces import IFooter
from karl.views.interfaces import IInvitationBoilerplate
from karl.views.interfaces import ILiveSearchEntry
from karl.views.utils import get_static_url


class InvitationBoilerplate(object):
    """ Policy for where to get terms of service and privacy statement
    """
    implements(IInvitationBoilerplate)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    @property
    def terms_and_conditions(self):
        site = find_site(self.context)
        legal = site.get('legal')
        if not legal:
            return u"<p>No terms of service document found</p>"
        return legal.text

    @property
    def privacy_statement(self):
        # no privacy statement desired
        return ''


class OxfamFooter(object):
    """ Multi-adapter for Oxfam-specific page footer.
    """
    implements(IFooter)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    def __call__(self, api):
        return render(
            'templates/footer.pt',
            dict(api=api),
            request=self.request,
            )

@implementer(ILiveSearchEntry)
def profile_livesearch_result(context, request):
    """Override karl.views.adapters to stuff full phone into extension.
    """
    photo = context.get('photo')
    if photo is None:
        thumbnail = get_static_url(request) + '/images/defaultUser.gif'
    else:
        thumbnail = thumb_url(photo, request, (85,85))
    return livesearch_dict(
        context, request,
        phone=context.phone,
        email=context.email,
        department=context.department,
        type='profile',
        category='profile',
        thumbnail=thumbnail,
        )
