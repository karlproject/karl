.. _pyramid_zcml_api:

:mod:`pyramid_zcml` API
-----------------------

.. automodule:: pyramid_zcml

.. autofunction:: load_zcml(spec='configure.zcml')

.. autofunction:: make_app(root_factory, package=None, filename='configure.zcml', settings=None)

.. autofunction:: includeme
