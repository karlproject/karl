def evolve(site):
    """This used to add the chatterbox.
    """
