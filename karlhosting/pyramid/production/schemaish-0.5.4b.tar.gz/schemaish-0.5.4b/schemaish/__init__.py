"""
A high-level schema definition package, using formencode for validation.
"""

# Import all public (or at least all frequently used) names from the schemaish
# package.
from schemaish.attr import *

