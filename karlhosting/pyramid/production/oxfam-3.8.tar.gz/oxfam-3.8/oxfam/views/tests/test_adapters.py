import unittest
from pyramid import testing
import karl.testing


class TestInvitationBoilerplate(unittest.TestCase):
    def setUp(self):
        testing.cleanUp()

    def tearDown(self):
        testing.cleanUp()

    def _getTargetClass(self):
        from oxfam.views.adapters import InvitationBoilerplate
        return InvitationBoilerplate

    def _makeOne(self, context, request):
        return self._getTargetClass()(context, request)

    def test_class_conforms_to_IInvitationBoilerplate(self):
        from zope.interface.verify import verifyClass
        from karl.views.interfaces import IInvitationBoilerplate
        verifyClass(IInvitationBoilerplate, self._getTargetClass())

    def test_terms_and_conditions(self):
        context = testing.DummyModel()
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        self.assertEqual(type(adapter.terms_and_conditions), unicode)
        self.assertTrue('terms' in adapter.terms_and_conditions)

    def test_privacy_statement(self):
        context = testing.DummyModel()
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        self.assertEqual(adapter.privacy_statement, '')


class TestOxfamFooter(unittest.TestCase):

    def _getTargetClass(self):
        from oxfam.views.adapters import OxfamFooter
        return OxfamFooter

    def _makeOne(self, context=None, request=None):
        if context is None:
            context = testing.DummyModel()
        if request is None:
            request = testing.DummyRequest()
        return self._getTargetClass()(context, request)

    def test_class_conforms_to_IFooter(self):
        from zope.interface.verify import verifyClass
        from karl.views.interfaces import IFooter
        verifyClass(IFooter, self._getTargetClass())

    def test_instance_conforms_to_IFooter(self):
        from zope.interface.verify import verifyObject
        from karl.views.interfaces import IFooter
        verifyObject(IFooter, self._makeOne())

    def test_it(self):
        renderer = karl.testing.registerDummyRenderer('templates/footer.pt')
        footer = self._makeOne()
        api = object()
        footer(api)
        self.failUnless(renderer.api is api)

