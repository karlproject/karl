from karl.utils import find_site
from karl.views.interfaces import IFooter
from karl.views.interfaces import IInvitationBoilerplate
from pyramid.renderers import render
from zope.interface import implements


class InvitationBoilerplate(object):
    """ Policy for where to get terms of service and privacy statement"""
    implements(IInvitationBoilerplate)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    @property
    def terms_and_conditions(self):
        site = find_site(self.context)
        legal = site.get('legal')
        if not legal:
            return u"<p>No terms of service document found</p>"
        return legal.text

    @property
    def privacy_statement(self):
        # no privacy statement desired
        return ''


class OxfamFooter(object):
    """ Multi-adapter for Oxfam-specific page footer.
    """
    implements(IFooter)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    def __call__(self, api):
        return render(
            'templates/footer.pt',
            dict(api=api),
            request=self.request,
            )
