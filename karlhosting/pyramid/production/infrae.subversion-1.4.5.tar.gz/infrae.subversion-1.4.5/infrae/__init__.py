# Copyright (c) 2007-2008 Infrae. All rights reserved.
# $Id$

__import__('pkg_resources').declare_namespace(__name__)
