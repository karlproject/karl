repoze.lemonade
===============

repoze.lemonade is a collection of utilties that make it possible to
create Zope CMF-like applications without requiring any particular
persistence mechanism.

See docs/index.rst for more information.

