#define PYLIBMC_VERSION "1.1.1-agendaless1"
