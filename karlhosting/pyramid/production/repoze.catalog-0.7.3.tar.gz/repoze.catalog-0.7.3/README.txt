================
 repoze.catalog
================

An indexing and searching system based on `zope.index`_.

.. _`zope.index`: http://pypi.python.org/pypi/zope.index

See the ``docs`` subdirectory for documentation or the `online docs
<http://docs.repoze.org/catalog/>`_.

