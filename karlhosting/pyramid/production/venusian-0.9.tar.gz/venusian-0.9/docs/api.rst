API Documentation for Venusian
==============================

.. automodule:: venusian

  .. autoclass:: Scanner

     .. automethod:: scan

  .. autoclass:: AttachInfo

  .. autofunction:: attach(wrapped, callback, category=None)

