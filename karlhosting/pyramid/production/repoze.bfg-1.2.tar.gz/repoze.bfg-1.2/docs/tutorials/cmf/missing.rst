Missing Comparisons
===================

We currently don't have any comparative BFG-vs-CMF information about
the following concepts within this tutorial:

- Templates

- Forms

- Membership

- Discussions

- Syndication

- Dublincore

Please ask on the `repoze-dev maillist
<http://lists.repoze.org/listinfo/repoze-dev>`_ or on the `#repoze IRC
channel <http://irc.freenode.net#repoze>`_ about these topics.

