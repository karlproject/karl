class MyModel(object):
    pass

root = MyModel()

def get_root(environ):
    return root
