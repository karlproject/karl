.. _router_module:

:mod:`repoze.bfg.router`
------------------------

.. automodule:: repoze.bfg.router

.. autofunction:: repoze.bfg.router.make_app(root_factory, package=None, filename='configure.zcml', settings=None)
