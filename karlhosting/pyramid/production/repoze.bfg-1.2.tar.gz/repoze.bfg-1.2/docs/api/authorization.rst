.. _authorization_module:

:mod:`repoze.bfg.authorization`
-------------------------------

.. automodule:: repoze.bfg.authorization

  .. autoclass:: ACLAuthorizationPolicy

