.. _url_module:

:mod:`repoze.bfg.url`
---------------------

.. automodule:: repoze.bfg.url

  .. autofunction:: repoze.bfg.url.model_url(context, request, *elements, query=None, anchor=None)

  .. autofunction:: route_url

  .. autofunction:: static_url

  .. autofunction:: urlencode

