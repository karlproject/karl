.. _scripting_module:

:mod:`repoze.bfg.scripting`
---------------------------

.. automodule:: repoze.bfg.scripting

  .. autofunction:: get_root

