.. _wsgi_module:

:mod:`repoze.bfg.wsgi`
--------------------------

.. automodule:: repoze.bfg.wsgi

  .. autofunction:: wsgiapp

  .. autofunction:: wsgiapp2
