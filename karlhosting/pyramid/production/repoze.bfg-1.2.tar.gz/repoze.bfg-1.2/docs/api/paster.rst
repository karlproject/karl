.. _paster_module:

:mod:`repoze.bfg.paster`
---------------------------

.. module:: repoze.bfg.paster

.. function:: get_app(config_file, name)

    Return the WSGI application named ``name`` in the PasteDeploy
    config file ``config_file``.

     
