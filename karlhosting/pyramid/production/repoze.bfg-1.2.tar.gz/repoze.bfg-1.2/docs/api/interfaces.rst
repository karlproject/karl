.. _interfaces_module:

:mod:`repoze.bfg.interfaces`
----------------------------

.. automodule:: repoze.bfg.interfaces

  .. autoclass:: IAfterTraversal

  .. autoclass:: INewRequest

  .. autoclass:: INewResponse

  .. autoclass:: IWSGIApplicationCreatedEvent


