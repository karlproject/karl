.. _settings_module:

:mod:`repoze.bfg.settings`
--------------------------

.. automodule:: repoze.bfg.settings

  .. autofunction:: get_settings

