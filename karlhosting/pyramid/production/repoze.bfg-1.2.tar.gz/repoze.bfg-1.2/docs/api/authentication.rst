.. _authentication_module:

:mod:`repoze.bfg.authentication`
--------------------------------

.. automodule:: repoze.bfg.authentication

  .. autoclass:: AuthTktAuthenticationPolicy

  .. autoclass:: RepozeWho1AuthenticationPolicy

  .. autoclass:: RemoteUserAuthenticationPolicy

