:mod:`repoze.bfg` Change History
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. include:: ../CHANGES.txt

.. include:: ../HISTORY.txt
