.. _translationstring_module:

API Documentation
-----------------

.. automodule:: translationstring

  .. autoclass:: TranslationString
     :members:
 
  .. autofunction:: TranslationStringFactory

  .. autofunction:: ChameleonTranslate

  .. autofunction:: Translator

  .. autofunction:: dugettext_policy

  .. autofunction:: ugettext_policy

  .. autofunction:: Pluralizer

  .. autofunction:: dungettext_policy

  .. autofunction:: ungettext_policy

