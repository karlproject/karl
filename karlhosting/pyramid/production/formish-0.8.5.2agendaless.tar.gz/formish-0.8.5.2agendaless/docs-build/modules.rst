Core formish Modules
====================

* :mod:`formish.forms` - Main Form and Field handling
* :mod:`formish.widgets` - Types of form field
* :mod:`formish.filehandler` - Temporary storage of file uploads
* :mod:`formish.fileresource` - Default fileaccessor and fileresource for restish

