formish.fileresource
====================

.. automodule:: formish.fileresource
    :members: FileAccessor, FileResource


