nosetests -d --with-spec --spec-color formish/tests
