bind = "unix:/tmp/bar/baz"
workers = 3
proc_name = "fooey"
default_proc_name = "blurgh"