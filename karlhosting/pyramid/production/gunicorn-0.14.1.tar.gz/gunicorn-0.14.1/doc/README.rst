Generate Documentation
----------------------

Requirements
++++++++++++

To generate documentation you need to install:

 - Python 2.x >= 2.5
 - jinja2 (http://jinja.pocoo.org/2/)
 - docutils (http://docutils.sourceforge.net/)
 - compass (http://compass-style.org/)
 - compass-960-plugin (http://github.com/chriseppstein/compass-960-plugin)
 
 
Generate
++++++++
::

    $ ./buildweb.py

Have a look in the file.py for configuration details.