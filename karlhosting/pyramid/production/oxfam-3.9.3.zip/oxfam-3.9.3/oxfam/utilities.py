from zope.interface import implements

from karl.views.interfaces import IReportColumns
from karl.views.peopledirectory import COLUMNS
from karl.views.peopledirectory import ReportColumn

class Columns(dict):
    implements(IReportColumns)

columns = Columns(COLUMNS)
del COLUMNS

# del columns['position'] # others???

columns.update({
    'employee_id': ReportColumn('employee_id', 'Employee ID'),
    'job_title': ReportColumn('job_title', 'Job Title'),
    'division': ReportColumn('division', 'Division'),
    'manager': ReportColumn('manager', 'Manager'),
    'business_mobile_phone': ReportColumn('business_mobile_phone',
                                          'Business Mobile Phone'),
    'skype_name': ReportColumn('skype_name', 'Skype Name'),
    'office_address': ReportColumn('office_address', 'Office Address'),
    })
