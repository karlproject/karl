from zope.interface import Attribute
from karl.models.interfaces import IProfile as IKarlProfile

class IProfile(IKarlProfile):
    employee_id = Attribute('Employee ID')
    job_title = Attribute('Job Title')
    team = Attribute('Tearm')
    division = Attribute('Division')
    manager = Attribute('Manager')
    business_mobile_phone = Attribute('Business Mobile Phone')
    skype_name = Attribute('Skype Name')
    office_address = Attribute('Office Address')
