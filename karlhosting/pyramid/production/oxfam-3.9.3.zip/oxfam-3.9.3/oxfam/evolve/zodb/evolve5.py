from karl.models.interfaces import ICatalogSearch
from karl.models.interfaces import IProfile


def evolve(context):
    search = ICatalogSearch(context)
    cnt, docids, resolver = search(interfaces=[IProfile],
                                   sort_index='name')
    for i, profile in enumerate([resolver(x) for x in docids]):
        log_name = profile.__name__.encode('ascii', 'replace')
        print 'Updating profile: [%08d of %08d] %s' % (i, cnt, log_name)
        profile._p_activate  # populate __dict__
        photo = profile.get('photo')
        if photo:
            photo.__parent__ = profile
        if not profile.job_title:
            profile.job_title = profile.position
