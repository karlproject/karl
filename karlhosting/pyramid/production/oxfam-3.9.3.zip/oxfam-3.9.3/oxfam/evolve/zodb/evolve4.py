from karl.models.interfaces import ICatalogSearch
from karl.models.interfaces import IProfile

def evolve(context):
    search = ICatalogSearch(context)
    cnt, docids, resolver = search(interfaces=[IProfile],
                                   sort_index='name')
    for i, profile in enumerate([resolver(x) for x in docids]):
        name = profile.__name__
        log_name = profile.__name__.encode('ascii', 'replace')
        print 'Updating profile: [%08d of %08d] %s' % (i, cnt, log_name)
        profile._p_activate #populate __dict__
        for attr in ['employee_id',
                     'job_title',
                     'team',
                     'division',
                     'manager',
                     'business_mobile_phone',
                     'skype_name',
                     'office_address',
                    ]:
            if attr not in profile.__dict__:
                setattr(profile, attr, u'')
