import formish
import schemaish

from karl.utils import find_users
from karl.views.admin import UploadUsersView as UUVBase
from karl.views.people import EditProfileFormController as EPFCBase
from karl.views.people import AdminEditProfileFormController as AEPFCBase

# new custom vields
employee_id_field = schemaish.String()
job_title_field = schemaish.String()
team_field = schemaish.String()
division_field = schemaish.String()
manager_field = schemaish.String()
business_mobile_phone_field = schemaish.String(title='Mobile Phone')
skype_name_field = schemaish.String()
office_address_field = schemaish.String()
# oerrides
languages_field = schemaish.String(title='Primary languages spoken')

_OXFAM_FIELDS = {'employee_id': employee_id_field,
                 'job_title': job_title_field,
                 'team': team_field,
                 'division': division_field,
                 'manager': manager_field,
                 'business_mobile_phone': business_mobile_phone_field,
                 'skype_name': skype_name_field,
                 'office_address': office_address_field,
                 'languages': languages_field,
                }

_STAFF_READONLY_FIELDS = [
    'firstname',
    'lastname',
    'employee_id',
    'job_title',
    'team',
    'department',
    'division',
    'manager',
    'email',
    'extension',
    'phone',
    'business_mobile_phone',
    'location',
    'office_address',
    'country',
    'organization',
    'languages',
]

class UploadUsersView(UUVBase):

    allowed_fields = UUVBase.allowed_fields + _OXFAM_FIELDS.keys()

class EditProfileFormController(EPFCBase):
    """
    Oxfam-specific formish controller for the profile edit form.
    
    Also the base class for the controllers for the admin profile edit and
    add user forms.
    """
    simple_field_names = [
        "firstname",
        "lastname",
        "employee_id",              #osfam
        "job_title",                #oxfam
        "team",                     #osfam
        "department",
        "division",                 #oxfam
        "manager",                  #oxfam
        "email",
        "extension",
        "phone",
        "business_mobile_phone",    #oxfam
        "skype_name",               #oxfam
        "fax",
        "location",
        "office_address",           #oxfam
        #"position",                #oxfam: use 'job_title' instead
        "country",
        "organization",
        "languages",
        #"websites",
        #"office",
        #"room_no",
        "biography",
        "date_format",
    ]

    def form_fields(self):
        karl_fields = super(EditProfileFormController, self).form_fields()
        kf_dict = dict(karl_fields)
        fields = []
        for name in self.simple_field_names:
            field = _OXFAM_FIELDS.get(name)
            if field is not None:
                fields.append((name, field))
            else:
                kf = kf_dict.get(name)
                if kf is not None:
                    fields.append((name, kf_dict[name]))
        # not in simple_field_names
        fields.insert(-1, ('photo', kf_dict['photo']))
        return fields

    def form_widgets(self, fields):
        context = self.context
        karl_widgets = super(EditProfileFormController, self
                            ).form_widgets(fields)
        widgets = karl_widgets.copy()
        widgets['country'] = formish.Input(empty='')
        widgets['office_address'] = formish.TextArea(empty='', rows=3, cols=40)
        users = find_users(context)
        userid = context.__name__
        user = users.get_by_id(userid)
        if 'group.KarlStaff' in user['groups']:
            for rfield in _STAFF_READONLY_FIELDS:
                widgets[rfield] = formish.Hidden()
        return widgets

    def form_defaults(self):
        context = self.context
        karl_defaults = super(EditProfileFormController, self
                             ).form_defaults()
        defaults = karl_defaults.copy()
        defaults['employee_id'] = context.employee_id
        defaults['job_title'] = context.job_title
        defaults['team'] = context.team
        defaults['division'] = context.division
        defaults['manager'] = context.manager
        defaults['business_mobile_phone'] = context.business_mobile_phone
        defaults['skype_name'] = context.skype_name
        defaults['office_address'] = context.office_address
        return defaults


class AdminEditProfileFormController(AEPFCBase):
    """ Extend the default controller w/ extra logic required by admin form.
    """
    @property
    def simple_field_names(self):
        context = self.context
        if self.user is not None:
            names = ['login', 'groups', 'home_path', 'password']
        else:
            names = ['home_path']
        return names + EditProfileFormController.simple_field_names

    def form_fields(self):
        karl_fields = super(AdminEditProfileFormController, self).form_fields()
        kf_dict = dict(karl_fields)
        fields = []
        for name in self.simple_field_names:
            field = _OXFAM_FIELDS.get(name)
            if field is not None:
                fields.append((name, field))
            else:
                kf = kf_dict.get(name)
                if kf is not None:
                    fields.append((name, kf))
        # not in simple_field_names
        fields.insert(-1, ('photo', kf_dict['photo']))
        return fields

    def form_widgets(self, fields):
        karl_widgets = super(AdminEditProfileFormController, self
                            ).form_widgets(fields)
        widgets = karl_widgets.copy()
        widgets['country'] = formish.Input(empty='')
        widgets['office_address'] = formish.TextArea(empty='', rows=3, cols=40)
        return widgets

    def form_defaults(self):
        context = self.context
        karl_defaults = super(AdminEditProfileFormController, self
                             ).form_defaults()
        defaults = karl_defaults.copy()
        defaults['employee_id'] = context.employee_id
        defaults['job_title'] = context.job_title
        defaults['team'] = context.team
        defaults['division'] = context.division
        defaults['manager'] = context.manager
        defaults['business_mobile_phone'] = context.business_mobile_phone
        defaults['skype_name'] = context.skype_name
        defaults['office_address'] = context.office_address
        return defaults
