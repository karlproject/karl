from karl.models.interfaces import IToolFactory
from karl.utils import find_site
from karl.views import site
from karl.views.interfaces import IFooter
from karl.views.interfaces import IInvitationBoilerplate
from karl.views.interfaces import ILayoutProvider
from karl.views.interfaces import IToolAddables
from pyramid.renderers import get_renderer
from pyramid.renderers import render
from pyramid.path import package_path
from repoze.lemonade.listitem import get_listitems
from zope.interface import implements
import os

class ToolAddables(object):
    """ Site-specific policies for adding tools to a community """
    implements(IToolAddables)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    def __call__(self):
        """ Modify the default list of what can go in a community """
        _tool_list = []
        communities_block = ['intranets', 'forums']
        for toolinfo in get_listitems(IToolFactory):
            if toolinfo['name'] not in communities_block:
                _tool_list.append(toolinfo)

        return _tool_list


class LayoutProvider(object):
    """ Site policy on which o-wrap to choose from for a context"""
    implements(ILayoutProvider)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    @property
    def community_layout(self):
        package_dir = package_path(site)
        template_fn = os.path.join(
            package_dir, 'templates', 'community_layout.pt')
        return get_renderer(template_fn).implementation()

    @property
    def generic_layout(self):
        package_dir = package_path(site)
        template_fn = os.path.join(
            package_dir, 'templates', 'generic_layout.pt')
        return get_renderer(template_fn).implementation()

    def __call__(self, name=None):
        # The layouts are by identifier, e.g. layout='community'
        if name is None:
            return None
        return getattr(self, name + '_layout')


class InvitationBoilerplate(object):
    """ Policy for where to get terms of service and privacy statement"""
    implements(IInvitationBoilerplate)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    @property
    def terms_and_conditions(self):
        site = find_site(self.context)
        legal = site.get('legal')
        if not legal:
            return u"<p>No terms of service document found</p>"
        return legal.text

    @property
    def privacy_statement(self):
        # no privacy statement desired
        return ''

def community_folder_addables(context, request):
    def get_addables():
        return [
            ('Add Folder', 'add_folder.html'),
            ('Add File', 'add_file.html')
            ]
    return get_addables


class OxfamFooter(object):
    """ Multi-adapter for Oxfam-specific page footer.
    """
    implements(IFooter)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    def __call__(self, api):
        return render(
            'templates/footer.pt',
            dict(api=api),
            request=self.request,
            )
