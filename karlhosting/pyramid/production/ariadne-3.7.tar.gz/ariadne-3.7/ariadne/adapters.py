from lxml.html import fragment_fromstring
from lxml.html import tostring
from lxml.etree import SubElement
from pyramid.security import effective_principals
from pyramid.url import resource_url
from zope.interface import implements

from karl.content.interfaces import IBlogEntry
from karl.models.interfaces import ICatalogSearch
from karl.utils import find_community
from karl.views.interfaces import IIntranetPortlet
from karl.workflow import public_community_containment

class RecentBlogPortletAdapter(object):
    implements(IIntranetPortlet)
    title = u'Recent Blog Entries'
    def __init__(self, context, request):
        self._context = context
        self._request = request

    @property
    def href(self):
        return resource_url(
                self._context, self._request, 'recent_blog_entries.html')

    @property
    def entries(self):
        searcher = self._request.registry.getAdapter(self._context,
                                                     ICatalogSearch,
                                                    )
        query = {'interfaces': [IBlogEntry],
                # 'limit': 5, # we can't limit:  post-processing
                 'reverse': True,
                 'sort_index': 'creation_date',
                 'allowed': {'query': effective_principals(self._request),
                             'operator': 'or',
                            },
                }
        total, docids, resolver = searcher(**query)

        if total == 0:
            return None

        entries = []
        for docid in docids:
            model = resolver(docid)
            if (public_community_containment(model) and
                getattr(model, 'security_state', None) != 'private'):
                entries.append({'title': model.title,
                                'href': resource_url(model, self._request),
                                'date': model.created,
                                'community': find_community(model),
                               })
                if len(entries) > 4:
                    break;
        return entries[:5]

    @property
    def asHTML(self):
        """Use lxml to generate a customizable via adapter representation"""

        portlet = fragment_fromstring('<div class="generic-portlet""/>')
        heading = SubElement(portlet, 'h3')
        heading.text = self.title

        # Now the entries
        entries = self.entries
        if entries:
            table = SubElement(portlet, 'table', id='blog_portlet')
            for entry in self.entries:
                tr = SubElement(table, 'tr')

                td1 = SubElement(tr, 'td')
                td1.set('class', 'entry_date')
                abbr = SubElement(td1, 'abbr')

                timeago = entry['data'].strftime('%Y-%m-%dT%H:%M:%SZ')
                abbr.set('title', timeago)
                abbr.set('class', 'timeago')

                td2 = SubElement(tr, 'td')
                td2.set('class', 'entry_title')
                span2 = SubElement(td2, 'span')
                a = SubElement(span2, 'a',
                               href=entry['href'],
                               style='text-decoration:none',
                              )
                a.text = entry['title']
                br = SubElement(td2, 'br')
                em = SubElement(td2, 'em')
                em.text = entry['community'].title
        else:
            msg = SubElement(portlet, 'p')
            msg.text = "No blog entries found"

        return tostring(portlet, pretty_print=True)
