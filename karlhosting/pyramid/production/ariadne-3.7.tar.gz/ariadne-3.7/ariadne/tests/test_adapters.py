import unittest

from pyramid import testing
from karl import testing as karltesting

class RecentBlogPortletAdapterTests(unittest.TestCase):

    def _getTargetClass(self):
        from ariadne.adapters import RecentBlogPortletAdapter
        return RecentBlogPortletAdapter

    def _makeOne(self, context=None, request=None):
        if context is None:
            context = karltesting.DummyModel()
        if request is None:
            request = testing.DummyRequest()
        return self._getTargetClass()(context, request)

    def _registerSearchAdapter(self, mapping):
        from zope.interface import Interface
        from karl.models.interfaces import ICatalogSearch
        _queries = []
        def _searcher(**query):
            _queries.append(query)
            return len(mapping), sorted(mapping.keys()), mapping.get
        karltesting.registerAdapter(lambda x: _searcher,
                                    (Interface), ICatalogSearch)
        return _queries

    def test_class_conforms_to_IIntranetPortlet(self):
        from zope.interface.verify import verifyClass
        from karl.views.interfaces import IIntranetPortlet
        verifyClass(IIntranetPortlet, self._getTargetClass())

    def test_instance_conforms_to_IIntranetPortlet(self):
        from zope.interface.verify import verifyObject
        from karl.views.interfaces import IIntranetPortlet
        self._registerSearchAdapter({})
        verifyObject(IIntranetPortlet, self._makeOne())

    def test_href(self):
        self._registerSearchAdapter({})
        rbp = self._makeOne()
        self.assertEqual(rbp.href,
                         'http://example.com/recent_blog_entries.html')

    def test_entries_catalog_empty(self):
        from karl.content.interfaces import IBlogEntry
        queries = self._registerSearchAdapter({})
        context = karltesting.DummyModel()
        rbp = self._makeOne()
        self.assertEqual(rbp.entries, None)
        self.assertEqual(queries,
                         [{'interfaces': [IBlogEntry],
                          #'limit': 5,
                           'reverse': True,
                           'sort_index': 'creation_date',
                           'allowed': {'query': [], 'operator': 'or'}
                          }])

    def test_entries_catalog_non_empty(self):
        from datetime import datetime
        from zope.interface import directlyProvides
        from karl.models.interfaces import ICommunity
        DATES = [datetime(2013,4,x) for x in range(1, 4)]
        context = karltesting.DummyModel()
        directlyProvides(context, ICommunity)
        context.security_state = 'public'
        e1 = context['e1'] = karltesting.DummyModel(title='One',
                                                    created=DATES[0],
                                                    security_state='inherits',
                                                   )
        e2 = context['e2'] = karltesting.DummyModel(title='Two',
                                                    created=DATES[1],
                                                    security_state='inherits',
                                                   )
        e3 = context['e3'] = karltesting.DummyModel(title='Three',
                                                    created=DATES[2],
                                                    security_state='inherits',
                                                   )
        self._registerSearchAdapter({1: e1, 2: e2, 3: e3})
        rbp = self._makeOne()
        self.assertEqual(list(rbp.entries),
                         [{'title': 'One',
                           'href': 'http://example.com/e1/',
                           'date': DATES[0],
                           'community': context,
                          },
                          {'title': 'Two',
                           'href': 'http://example.com/e2/',
                           'date': DATES[1],
                           'community': context,
                          },
                          {'title': 'Three',
                           'href': 'http://example.com/e3/',
                           'date': DATES[2],
                           'community': context,
                          },
                         ])

    def test_entries_skips_items_in_private_community(self):
        from datetime import datetime
        from zope.interface import directlyProvides
        from karl.models.interfaces import ICommunity
        DATES = [datetime(2013,4,x) for x in range(1, 4)]
        context = karltesting.DummyModel()
        directlyProvides(context, ICommunity)
        context.security_state = 'public'
        private = karltesting.DummyModel()
        directlyProvides(private, ICommunity)
        private.security_state = 'private'
        e1 = context['e1'] = karltesting.DummyModel(title='One',
                                                    created=DATES[0],
                                                    security_state='inherits',
                                                   )
        e2 = context['e2'] = karltesting.DummyModel(title='Two',
                                                    created=DATES[1],
                                                    security_state='inherits',
                                                   )
        e3 = private['e3'] = karltesting.DummyModel(title='Three',
                                                    created=DATES[2],
                                                    security_state='inherits',
                                                   )
        self._registerSearchAdapter({1: e1, 2: e2, 3: e3})
        rbp = self._makeOne()
        self.assertEqual(list(rbp.entries),
                         [{'title': 'One',
                           'href': 'http://example.com/e1/',
                           'date': DATES[0],
                           'community': context,
                          },
                          {'title': 'Two',
                           'href': 'http://example.com/e2/',
                           'date': DATES[1],
                           'community': context,
                          },
                         ])

    def test_entries_skips_private_entry(self):
        from datetime import datetime
        from zope.interface import directlyProvides
        from karl.models.interfaces import ICommunity
        DATES = [datetime(2013,4,x) for x in range(1, 4)]
        context = karltesting.DummyModel()
        directlyProvides(context, ICommunity)
        context.security_state = 'public'
        e1 = context['e1'] = karltesting.DummyModel(title='One',
                                                    created=DATES[0],
                                                    security_state='inherits',
                                                   )
        e2 = context['e2'] = karltesting.DummyModel(title='Two',
                                                    created=DATES[1],
                                                    security_state='inherits',
                                                   )
        e3 = context['e3'] = karltesting.DummyModel(title='Three',
                                                    created=DATES[2],
                                                    security_state='private',
                                                   )
        self._registerSearchAdapter({1: e1, 2: e2, 3: e3})
        rbp = self._makeOne()
        self.assertEqual(list(rbp.entries),
                         [{'title': 'One',
                           'href': 'http://example.com/e1/',
                           'date': DATES[0],
                           'community': context,
                          },
                          {'title': 'Two',
                           'href': 'http://example.com/e2/',
                           'date': DATES[1],
                           'community': context,
                          },
                         ])
