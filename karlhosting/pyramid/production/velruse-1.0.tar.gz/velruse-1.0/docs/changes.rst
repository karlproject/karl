:tocdepth: 2

.. _changes:

Changes
*******

.. the ******-heading is used to override the ===== in CHANGES.rst

.. include:: ../CHANGES.rst
