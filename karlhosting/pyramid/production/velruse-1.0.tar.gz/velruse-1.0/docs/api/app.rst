:mod:`velruse.app`
==================

.. automodule:: velruse.app

   .. autofunction:: default_setup

   .. autofunction:: register_velruse_store

   .. autofunction:: make_app
