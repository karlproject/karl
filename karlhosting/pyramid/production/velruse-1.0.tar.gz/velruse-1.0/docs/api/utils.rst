:mod:`velruse.utils`
====================

.. automodule:: velruse.utils

   .. autofunction:: flat_url
