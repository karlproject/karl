/*
 * memberbox unit tests
 */
(function($) {

module("karl: memberbox");

test('true', function() {

});

})(jQuery);