/*
 * livesearch unit tests
 */
(function($) {

module("karl: livesearch");


// activate

test('activate', function() {
  
});


// _setupWidget

test('setupWidget', function() {

});


// _getBoxOnEnter

test('getBoxOnEnter()', function() {

});


})(jQuery);