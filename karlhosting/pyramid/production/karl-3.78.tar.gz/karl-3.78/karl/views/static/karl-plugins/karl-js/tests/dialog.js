/*
 * dialog unit tests
 */
(function($) {

module("karl: dialog");

test('true', function() {

});

})(jQuery);