
(function($){

// XXX This code is currently in karl.js


})(jQuery);

