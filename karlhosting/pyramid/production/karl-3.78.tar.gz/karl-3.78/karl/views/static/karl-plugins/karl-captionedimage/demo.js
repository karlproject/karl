
(function($){

    $(document).ready(function() {

        $('.image').karlcaptionedimage({
        });

    });

})(jQuery);

