
/**
* jQuery 1.6.2 + jQuery UI 1.9m6 resource combo
* You have to use juicer to produce a minified resource based on this file
* You cannot use this file as a development resource
*
*     @depends ../jquery/jquery-1.6.2.js
*     @depends jquery-ui-1.9m5.js
*
*
*
*/

