/**
* KARL ux2 slickgrid resource composition
* You have to use juicer to produce a minified resource based on this file
* You cannot use this file as a development resource
*
*    @depends ../../slick/2.0.1/lib/jquery.event.drag-2.0.min.js
*    @depends ../../slick/2.0.1/lib/jquery.event.drop-2.0.min.js
*    @depends ../../slick/2.0.1/slick.core.js
*    
*        @ NOT depends ../../slick/2.0.1/slick.editors.js
*        @ NOT depends ../../slick/2.0.1/plugins/slick.cellrangedecorator.js
*        @ NOT depends ../../slick/2.0.1/plugins/slick.cellrangeselector.js
*        @ NOT depends ../../slick/2.0.1/plugins/slick.cellselectionmodel.js
*
*    @depends ../../slick/2.0.1/plugins/slick.rowselectionmodel.js
*    @depends ../../slick/2.0.1/plugins/slick.checkboxselectcolumn.js
*    @depends ../../slick/2.0.1/slick.grid.js
*    @depends ../../slick/2.0.1/slick.dataview.js
*    @depends ../../slick/2.0.1/slick.groupitemmetadataprovider.js
*
*    @depends ../plugins/popper-gridbox/karl.wikitoc.js
*    @depends ../plugins/popper-gridbox/popper.gridbox.js       
*
*/

