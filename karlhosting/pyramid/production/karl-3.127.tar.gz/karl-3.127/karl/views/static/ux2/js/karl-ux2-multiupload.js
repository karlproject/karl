/**
* KARL ux2 multiupload resource composition
* You have to use juicer to produce a minified resource based on this file
* You cannot use this file as a development resource
*
*     @depends ../../plupload/src/javascript/gears_init.js
*     @depends ../../plupload/src/javascript/plupload.js
*     @depends ../../plupload/src/javascript/plupload.gears.js
*     @depends ../../plupload/src/javascript/plupload.silverlight.js
*     @depends ../../plupload/src/javascript/plupload.flash.js
*     @depends ../../plupload/src/javascript/plupload.html4.js
*     @depends ../../plupload/src/javascript/plupload.html5.js
*     @depends ../../plupload/src/javascript/jquery.ui.plupload.js
*     @depends ../plugins/karl-multifileupload/json2.js
*     @depends ../plugins/karl-multifileupload/karl.dialog.js
*     @depends ../plugins/karl-multifileupload/karl.multifileupload.js
*
*/

