.. _glossary:

Glossary
========

.. glossary::
   :sorted:

   formish
     A `form generation library
     <http://ish.io/projects/show/formish>`_ by Tim Parkin and Matt
     Goodall

   validatish
     A `validation library <http://ish.io/projects/show/validatish>`_
     by Tim Parkin and Matt Goodall
