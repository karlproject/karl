"""
Convertish is a module for casting/coercing to and from types. It uses
simplegeneric to adapt.

The only converters currently implemented using schemaish types
"""
