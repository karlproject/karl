# Copyright (C) 2008-2009 Open Society Institute
# Copyright (C) 2008-2009 Open Society Institute
#               Thomas Moroz: tmoroz@sorosny.org
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License Version 2 as published
# by the Free Software Foundation.  You may not use, modify or distribute
# this program under any other version of the GNU General Public License.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
""" Run GSA sync against a given data source.
"""
import datetime
import logging
import sys

import transaction
from ZODB.POSException import ConflictError

from karlserve.instance import set_current_instance
from karlserve.log import set_subsystem
from osi.sync.gsa_sync import GsaSync
from osi.sync.gsa_sync import get_last_sync


log = logging.getLogger(__name__)


def config_parser(name, subparsers, **helpers):
    parser = subparsers.add_parser(
        name, help='Sync staff profiles and login to OSI GSA.')
    helpers['config_daemon_mode'](parser, 120)
    parser.add_argument('-u', '--user', help='Login username for GSA.')
    parser.add_argument('-p', '--password', help='Password for GSA.')
    parser.add_argument('-x', '--check-last-sync',
                        default=None,
                        help='Check that last sync w/ GSA happened w/in a'
                             'given interval (in minutes).  If not, exit with '
                             'a non-zero status code;  if os, exit normally.')
    parser.add_argument('inst', metavar='instance',
                        help='Instance name.  Must be an OSI instance.')
    parser.add_argument('url', help='URL of GSA datasource.')
    parser.add_argument('-t', '--timeout',
                        default=15,
                        help='Timeout for GSA request (default 15 sec).')
    parser.set_defaults(func=main, parser=parser, subsystem='gsa_sync',
                        only_one=True)


def main(args):
    if not args.is_normal_mode(args.inst):
        log.info("Skipping %s: Running in maintenance mode." % args.inst)
        return

    site, closer = args.get_root(args.inst)
    set_subsystem('gsa_sync')
    set_current_instance(args.inst)
    settings = site._p_jar.root.instance_config

    if args.check_last_sync is not None:
        minutes = int(args.check_last_sync)
        delta = datetime.timedelta(0, minutes * 60)
        now = datetime.datetime.now()
        when = get_last_sync(site, args.url)
        if when is None:
            log.error('sync never initialized')
            sys.exit(1)
        if (now - when > delta):
            log.error('sync stalled:  last success: %s' % when.isoformat())
            sys.exit(1)
        return

    if settings.get('package') != 'osi':
        args.parser.error("GSA Sync must be used with an OSI instance.")
    timeout = int(args.timeout)
    try:
        gsa_sync = GsaSync(site, args.url, args.user, args.password,
                           timeout=timeout)
    except Exception as e:
        log.info('Could not connect to GSA: %s' % str(e))

    tries = 0
    success = False
    RETRIES = 3
    while tries < RETRIES:
        transaction.begin()
        try:
            gsa_sync()
            transaction.commit()
        except ConflictError:
            tries += 1
            site._p_jar.sync()
        else:
            success = True
            break
    if not success:
        log.critical('GSA Sync retry failed after %s tries' % RETRIES)
    closer()
