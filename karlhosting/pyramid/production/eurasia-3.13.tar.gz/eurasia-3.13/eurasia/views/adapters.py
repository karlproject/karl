
from karl.content.interfaces import ICalendarEvent
from karl.content.interfaces import IForum
from karl.content.interfaces import IReferencesFolder
from karl.content.interfaces import IReferenceManual
from karl.content.interfaces import IReferenceSection
from karl.content.views.interfaces import INetworkEventsMarker
from karl.content.views.interfaces import INetworkNewsMarker
from karl.models.interfaces import IIntranet
from karl.models.interfaces import IIntranets
from karl.models.interfaces import ISite
from karl.models.interfaces import IToolFactory
from karl.views import site
from karl.views.interfaces import IFooter
from karl.views.interfaces import IFolderAddables
from karl.views.interfaces import IToolAddables
from os.path import join
from repoze.bfg.chameleon_zpt import get_template
from repoze.bfg.chameleon_zpt import render_template
from repoze.bfg.path import package_path
from repoze.bfg.traversal import find_interface
from repoze.lemonade.listitem import get_listitems
from zope.interface import implements

class ToolAddables(object):
    """ Site-specific policies for adding tools to a community """
    implements(IToolAddables)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    def __call__(self):
        """ Modify the default list of what can go in a community """

        # Find out if we are adding this community from somewhere
        # inside the "intranets" side
        intranets = find_interface(self.context, IIntranets)
        is_site = ISite.providedBy(self.context)

        _tool_list = []
        intranets_block = ['wiki', 'blog']
        communities_block = ['intranets', 'forums']
        for toolinfo in get_listitems(IToolFactory):
            if intranets or is_site:
                if toolinfo['name'] not in intranets_block:
                    _tool_list.append(toolinfo)
            else:
                if toolinfo['name'] not in communities_block:
                    _tool_list.append(toolinfo)

        return _tool_list


class EurasiaFooter(object):
    """ Multi-adapter for Eurasia-specific page footer.
    """
    implements(IFooter)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    def __call__(self, api):
        return render_template(
            'templates/footer.pt',
            api=api,
            )
