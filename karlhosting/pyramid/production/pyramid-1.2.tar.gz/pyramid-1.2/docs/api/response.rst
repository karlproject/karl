.. _response_module:

:mod:`pyramid.response`
---------------------------

.. module:: pyramid.response

.. autoclass:: Response
   :members:
   :inherited-members:

Functions
~~~~~~~~~

.. autofunction:: response_adapter

