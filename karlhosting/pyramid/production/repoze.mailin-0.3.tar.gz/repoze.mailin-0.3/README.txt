repoze.mailin README
====================

This package provides a framework for mapping inbound e-mail onto
application-defined handlers.

Please see docs/index.rst for the documentation.
