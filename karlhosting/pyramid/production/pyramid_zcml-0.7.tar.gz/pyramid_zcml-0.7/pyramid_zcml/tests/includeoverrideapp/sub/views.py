from pyramid.response import Response

def theview(request): return Response('thesubview')

