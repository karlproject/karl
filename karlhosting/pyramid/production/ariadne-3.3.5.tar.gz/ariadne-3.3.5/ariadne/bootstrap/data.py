import pkg_resources

from zope.interface import implements

from karl.bootstrap.interfaces import IInitialOfficeData
from karl.bootstrap.data import DefaultInitialData

from repoze.bfg.security import Allow

from karl.security.policy import ADMINISTRATOR_PERMS
from karl.security.policy import GUEST_PERMS
from karl.security.policy import NO_INHERIT

sample_feature = """\
<div>
  <div class="teaser">
    <a href="http://karlproject.org/">
      <img src="/static/images/sample_feature.jpg" />
    </a>
  </div>
  <div class="visualClear"></div>
  <div class="featureLinks">
    <p>
      <a href="http://karlproject.org/newinkarl3.html">What's new in Karl3</a>
    </p>
    <p>
      <a href="http://karlproject.org/isandisnot.html">What Karl is and is not</a>
    </p>
    <p>
      <a href="http://karlproject.org/background.html">Background of Karl</a>
    </p>
    <p>
      <a href="http://dev.karlproject.org/">Developer site</a>
    </p>
  </div>
</div>
"""

navmenu_template = u"""\
<div>
  <div class="menu">
    <h3>About Ariadne</h3>
    <ul class="nav">
      <li>
        <a href="#" target="" title="">About Ariadne</a>
      </li>
      <li>
        <a href="/people" target="" title="">Network Directory</a>
      </li>
    </ul>
  </div>

  <div class="menu">
  <h3>Resources</h3>
     <ul class="nav">
       <li>
         <a href="#" target="" title="">Link</a>
       </li>
       <li>
         <a href="#" target="" title="">Link</a>
       </li>
       <li>
         <a href="#" target="" title="">Link</a>
       </li>
       <li>
         <a href="#" target="" title="">Link</a>
       </li>
       <li>
         <a href="#" target="" title="">Link</a>
       </li>
       <li>
         <a href="#" target="" title="">Link</a>
       </li>
     </ul>
  </div>

  <div class="menu">
   <h3>KARL Resources</h3>
   <ul class="nav">
     <li class="nav">
       <a href="/communities/about-karl" target="" title="About KARL">About KARL Community</a>
     </li>
     <li class="nav">
       <a href="/communities/about-karl/wiki/karl-user-manual" target="" title="User Manual">User Manual</a>
     </li>
     <li class="nav">
       <a href="/communities/about-karl/wiki/frequently-asked-questions/" target="" title="FAQ">FAQ's</a>
     </li>
     <li class="nav">
       <a href="/communities/karl-feedback/" target="" title="KARL Feedback">KARL Feedback Community</a>
     </li>
   </ul>
  </div>
</div>
"""

class SampleInitialData(DefaultInitialData):
    users_and_groups = [
        ('admin', 'Ad','Min','admin@example.com',
         ('group.KarlAdmin', 'group.KarlUserAdmin', 'group.KarlStaff')),
        ('nyc', 'En', 'Wycee', 'nyc@example.com',
         ('group.KarlStaff',)),
        ('affiliate', 'Aff', 'Illiate', 'affiliate@example.com',
         ('group.KarlAffiliate',)),
        ('staff1','Staff','One','staff1@example.com',
         ('group.KarlStaff',)),
        ('affiliate1','Affiliate','One','affiliate1@example.com',
         ('groups.KarlAffiliate',)),
        ('affiliate2','Affiliate','Two','affiliate2@example.com',
         ('groups.KarlAffiliate',))
    ]

sample_forums = [
    {'id': 'ariadne-events', 'title': 'Ariadne Office Events' },
    {'id': 'ariadne-news', 'title': 'Ariadne Office News' },
    {'id': 'ariadne-personals', 'title': 'Ariadne Office Personals' },
    ]

class SampleInitialOfficeData(object):
    implements(IInitialOfficeData)

    title = 'Ariande'

    offices = [
        {'id': 'ariadne',
         'title': 'Ariadne Network',
         'address': '338 City Road',
         'city': 'London',
         'state': '',
         'country': 'UK',
         'zipcode': 'EC1V 2PY',
         'telephone': '+44-20-723-98253',
          'middle_portlets': [ '/offices/files/network-news','/offices/files/network-events'],
          'right_portlets': ['/offices/ariadne/forums/ariadne-events','/offices/ariadne/forums/ariadne-news','/offices/ariadne/forums/ariadne-personals'],
         'forums': sample_forums,
         'navmenu': navmenu_template % {
             'org': 'ariadne',
             'org_upper': 'Ariadne Network'},
         },
    ]

    offices_acl = [
        (Allow, 'group.KarlAdmin', ADMINISTRATOR_PERMS),
        (Allow, 'group.KarlStaff', GUEST_PERMS),
        NO_INHERIT,
    ]

    feature = sample_feature

    @property
    def pages(self):
        return [
            ('terms_and_conditions', 'Terms and Conditions',
             pkg_resources.resource_stream(
                 __name__, 'pages/terms_and_conditions.html').read()),
             ('privacy_statement', 'Privacy Statement',
              pkg_resources.resource_stream(
                  __name__, 'pages/privacy_statement.html').read()),
        ]
