repoze.depinj README
====================

A dependency injection framework for unit testing that uses the Zope
Component Architecture.

Please see docs/index.rst in the package or
`http://docs.repoze.org/depinj <http://docs.repoze.org/depinj>`_ for
the documentation.
