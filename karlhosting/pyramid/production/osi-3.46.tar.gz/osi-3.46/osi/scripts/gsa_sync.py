# Copyright (C) 2008-2009 Open Society Institute
#               Thomas Moroz: tmoroz@sorosny.org
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License Version 2 as published
# by the Free Software Foundation.  You may not use, modify or distribute
# this program under any other version of the GNU General Public License.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
""" Run GSA sync against a given data source.
"""
import transaction

from karlserve.instance import set_current_instance
from karlserve.log import set_subsystem
from osi.sync.gsa_sync import GsaSync

import logging

log = logging.getLogger(__name__)


def config_parser(name, subparsers, **helpers):
    parser = subparsers.add_parser(
        name, help='Sync staff profiles and login to OSI GSA.')
    helpers['config_daemon_mode'](parser, 120)
    parser.add_argument('-u', '--user', help='Login username for GSA.')
    parser.add_argument('-p', '--password', help='Password for GSA.')
    parser.add_argument('inst', metavar='instance',
                        help='Instance name.  Must be an OSI instance.')
    parser.add_argument('url', help='URL of GSA datasource.')
    parser.set_defaults(func=main, parser=parser, subsystem='gsa_sync',
                        only_one=True)


def main(args):
    if not args.is_normal_mode(args.inst):
        log.info("Skipping %s: Running in maintenance mode." % args.inst)
        return

    site, closer = args.get_root(args.inst)
    set_subsystem('gsa_sync')
    set_current_instance(args.inst)
    settings = site._p_jar.root.instance_config
    if settings.get('package') != 'osi':
        args.parser.error("GSA Sync must be used with an OSI instance.")
    gsa_sync = GsaSync(site, args.url, args.user, args.password)
    gsa_sync()
    site._p_jar.db().cacheMinimize() # Attempt to fix memory leak
    transaction.commit()
    closer()
