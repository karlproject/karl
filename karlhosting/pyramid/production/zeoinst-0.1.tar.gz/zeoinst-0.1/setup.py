__version__ = '0.1'

from setuptools import setup, find_packages

requires = [
    'argparse'
]

setup(name='zeoinst',
      version=__version__,
      description='ZEO Instance Tools for Karl Production Install',
      packages=find_packages(),
      include_package_data=True,
      zip_safe=False,
      install_requires = requires,
      entry_points = """\
      [console_scripts]
      zeoinst = zeoinst.main:main
      [zeoinst.scripts]
      cleanup = zeoinst.cleanup:config_parser
      migrate = zeoinst.migrate:config_parser
      mkinst = zeoinst.mkinst:config_parser
      prep = zeoinst.update:config_parser_prep
      update = zeoinst.update:config_parser_update
      """
      )

