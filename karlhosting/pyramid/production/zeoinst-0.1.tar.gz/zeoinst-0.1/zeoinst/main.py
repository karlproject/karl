import argparse
import ConfigParser
import getpass
import logging
import os
import pkg_resources
import subprocess
import sys
import time

log = logging.getLogger(__name__)


def main(argv=sys.argv, out=None):
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s %(levelname)s %(name)s: %(message)s')

    # ZEO is a bit too chatty, if you ask me.
    zeo_logger = logging.getLogger('ZEO')
    zeo_logger.setLevel(logging.WARN)

    parser = argparse.ArgumentParser()
    parser.add_argument('-C', '--config', metavar='FILE', default=None,
                        help='Path to configuration ini file.')
    parser.add_argument('-I', '--instance', metavar='NAME', default=None,
                        help='ZEO instance.  Defaults to name of effective '
                        'UNIX userid.')
    subparsers = parser.add_subparsers(
        title='command', help='Available commands.')
    eps = [ep for ep in pkg_resources.iter_entry_points('zeoinst.scripts')]
    eps.sort(key=lambda ep: ep.name)
    ep_names = set()
    for ep in eps:
        if ep.name in ep_names:
            raise RuntimeError('script defined more than once: %s' % ep.name)
        ep_names.add(ep.name)
        ep.load()(ep.name, subparsers, **helpers)

    args = parser.parse_args(argv[1:])
    config_file = args.config
    if config_file is None:
        config_file = get_default_config()
    name = args.instance
    if name is None:
        args.instance = name = getpass.getuser()

    config = {'bin_dir': get_bin()}
    config_parser = ConfigParser.ConfigParser(config)
    config_parser.read(config_file)
    config.update(config_parser.items('DEFAULT'))
    config.update(config_parser.items(name))
    if 'path' not in config:
        config['path'] = get_default_instance_dir(args)
    args.config = config

    args.start_supervisor = start_supervisor(args)
    args.stop_supervisor = stop_supervisor(args)
    args.current_data_dir = current_data_dir(args)
    args.next_data_dir = next_data_dir(args)
    args.shell = shell
    args.func(args)


def get_default_config():
    exe = os.path.abspath(sys.argv[0])
    env = os.path.dirname(os.path.dirname(exe))
    return os.path.join(env, 'etc', 'zeoinst.ini')


def get_bin():
    exe = os.path.abspath(sys.argv[0])
    return os.path.dirname(exe)


def get_default_instance_dir(args):
    home = '~%s' % args.instance
    home = os.path.expanduser(home)
    return os.path.join(home, 'zeo')


def shell(cmd):
    """
    Run a command as though it were being called from a shell script.
    """
    log.info(cmd)
    return subprocess.check_call(cmd, shell=True)


def start_supervisor(args):
    def func():
        instance_dir = args.config['path']
        config_file = os.path.join(instance_dir, 'etc', 'supervisord.conf')
        exe = os.path.join(get_bin(), 'supervisord')
        shell("%s -c %s" % (exe, config_file))
    return func


def stop_supervisor(args):
    def func():
        instance_dir = args.config['path']
        config_file = os.path.join(instance_dir, 'etc', 'supervisord.conf')
        exe = os.path.join(get_bin(), 'supervisorctl')
        shell("%s -c %s shutdown" % (exe, config_file))
        pid_file = os.path.join(instance_dir, 'var', 'supervisord.pid')
        while os.path.exists(pid_file):
            log.info("Waiting for supervisor to shutdown...")
            time.sleep(1)
    return func


def current_data_dir(args):
    def func():
        instance_dir = args.config['path']
        path = os.path.join(instance_dir, 'data', 'current')
        return os.path.realpath(path)
    return func


def next_data_dir(args):
    def func():
        cur = args.current_data_dir()
        data_dir, index = os.path.split(cur)
        next_index = str(int(index) + 1)
        return os.path.join(data_dir, next_index)
    return func


helpers = {}
