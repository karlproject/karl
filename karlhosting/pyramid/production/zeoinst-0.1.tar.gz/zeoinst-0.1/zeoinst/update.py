import os


def config_parser_prep(name, subparsers, **helpers):
    parser = subparsers.add_parser(
        name, help='Prepare a ZEO instance for update, by copying data.')
    parser.set_defaults(func=prep, parser=parser)


def config_parser_update(name, subparsers, **helpers):
    parser = subparsers.add_parser(
        name, help='Switch to a new copy of data.')
    parser.set_defaults(func=update, parser=parser)


def prep(args):
    cur_data = args.current_data_dir()
    next_data = args.next_data_dir()
    if os.path.exists(next_data):
        args.parser.error("Database instance is already prepped.")
    os.mkdir(next_data)
    args.shell("rsync -a %s/ %s/" % (cur_data, next_data))


def update(args):
    cur_data = args.current_data_dir()
    next_data = args.next_data_dir()
    if not os.path.exists(next_data):
        args.parser.error("Database instance hasn't been prepped.")
    args.stop_supervisor()
    args.shell("rsync -a %s/ %s/" % (cur_data, next_data))
    link = os.path.join(os.path.dirname(cur_data), 'current')
    os.remove(link)
    os.symlink(next_data, link)
    args.start_supervisor()
