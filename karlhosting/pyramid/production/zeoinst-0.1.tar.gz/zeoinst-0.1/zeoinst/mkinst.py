from __future__ import with_statement

import os


def config_parser(name, subparsers, **helpers):
    parser = subparsers.add_parser(
        name, help='Create a new zeo instance.')
    parser.set_defaults(func=main, parser=parser)


def main(args):
    config = args.config
    path = config.get('path')
    if os.path.exists(path):
        args.parser.error(
            "Cannot create instance.  Directory already exists: %s" %
            path
        )
    os.makedirs(path)
    mkskeleton(dirs_template, path, config)
    curdata = os.path.join(path, 'data', '1')
    link = os.path.join(path, 'data', 'current')
    os.symlink(curdata, link)
    args.start_supervisor()


def mkskeleton(templates, curdir, config):
    for name, template in templates.items():
        path = os.path.join(curdir, name)
        if isinstance(template, dict):
            os.mkdir(path)
            mkskeleton(template, path, config)
        else:
            with open(path, 'w') as out:
                out.write(template % config)


zeo_conf_template = """
%%define INSTANCE %(path)s

<zeo>
  address %(zeo_port)s
  read-only false
  invalidation-queue-size 100
  pid-filename $INSTANCE/var/ZEO.pid
  # monitor-address PORT
  # transaction-timeout SECONDS
</zeo>

<blobstorage 1>
  <filestorage>
    path $INSTANCE/data/current/karl.db
  </filestorage>
  blob-dir $INSTANCE/data/current/blobs
</blobstorage>
"""

supervisord_conf_template = """
[inet_http_server]
port=127.0.0.1:%(supervisord_port)s

[supervisord]
logfile=%%(here)s/../log/supervisord.log
logfile_maxbytes=50MB
logfile_backups=10
loglevel=info
pidfile=%%(here)s/../var/supervisord.pid
nodaemon=false

[rpcinterface:supervisor]
supervisor.rpcinterface_factory = supervisor.rpcinterface:make_main_rpcinterface

[supervisorctl]
serverurl=http://127.0.0.1:%(supervisord_port)s

[program:zeo]
command = %(bin_dir)s/runzeo -C %%(here)s/zeo.conf
redirect_stderr = true
stdout_logfile = %%(here)s/../log/zeo.log
"""


dirs_template = {
    'var': {},
    'data': {
        '1': {
            'blobs': {},
        },
    },
    'etc': {
        'zeo.conf': zeo_conf_template,
        'supervisord.conf': supervisord_conf_template,
    },
    'log': {},
}
