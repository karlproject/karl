import os


def config_parser(name, subparsers, **helpers):
    parser = subparsers.add_parser(
        name, help='Copy data from current production for migration.')
    parser.set_defaults(func=main, parser=parser)


def main(args):
    config = args.config
    if 'migration.db_file' not in config:
        args.parser.error("Missing configuration: migration.db_file")
    if 'migration.blobs' not in config:
        args.parser.error("Missing configuration: migration.blobs")
    current_data = args.current_data_dir()
    if not os.path.exists(current_data):
        args.parser.error("Database instance hasn't been prepped.")
    args.stop_supervisor()
    db_file = os.path.join(current_data, 'karl.db')
    blobs = os.path.join(current_data, 'blobs')
    args.shell("rsync %s %s" % (config['migration.db_file'], db_file))
    args.shell("rsync -a %s/ %s/" % (config['migration.blobs'], blobs))
    link = os.path.join(os.path.dirname(current_data), 'current')
    os.remove(link)
    os.symlink(current_data, link)
    args.start_supervisor()
