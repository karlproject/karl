import os
import shutil


def config_parser(name, subparsers, **helpers):
    parser = subparsers.add_parser(
        name, help='Clean up old data folders.')
    parser.add_argument('--keep', type=int, default=2,
            help='Number of data folders to keep, not including the current.')
    parser.set_defaults(func=main, parser=parser)


def main(args):
    if args.keep < 0:
        args.parser.error("Argument to --keep must be 0 or greater.")

    # Get current data dir
    config = args.config
    datadir = os.path.join(config['path'], 'data')
    curdir = os.path.realpath(os.path.join(datadir, 'current'))
    if not os.path.exists(curdir):
        args.parser.error("No such folder: %s" % curdir)
    curdir = int(os.path.split(curdir)[1])

    # Get all data dirs
    subdirs = []
    for subdir in os.listdir(datadir):
        path = os.path.join(datadir, subdir)
        if os.path.isdir(path) and not os.path.islink(path):
            subdirs.append(int(subdir))
    subdirs.sort()

    # Compute folders to keep
    index = subdirs.index(curdir)
    keepers = [curdir]
    for i in range(args.keep):
        if index == 0:
            break
        index -= 1
        keepers.append(subdirs[index])

    # Compute folders to delete
    trash = [os.path.join(datadir, str(subdir)) for subdir in subdirs
             if subdir not in keepers]

    if not trash:
        print "Nothing to remove."
        return

    # Get user confirmation to delete
    print "The following folders will be deleted:"
    for path in trash:
        print "\t%s" % path
    print ""
    answer = ''
    while answer not in ('y', 'n', 'yes', 'no'):
        answer = raw_input("Delete these folders? (y or n) ").lower()
    if answer in ('y', 'yes'):
        for path in trash:
            shutil.rmtree(path)
        count = len(trash)
        if count == 1:
            print "One folder deleted."
        else:
            print "%d folders deleted." % count
    else:
        print "No folders deleted."
