/**
* Bottlecap livesearch resource composition
* You have to use juicer to produce a minified resource based on this file
* You cannot use this file as a development resource
*
* XXX bottlecap must be checked out from git to static/bottlecap manually!!!
*
* jq-base:
*     @ NOT depends ../bottlecap/sl/min/jq-base.js    --- jq-base is constracted locally from karl.

* bc-core: 
*     @depends ../bottlecap/sl/min/bc-core.js
*
* livesearch:
*     @depends ../bottlecap/bc.livesearch/livesearch.js
*   
*
*/

