=================
 repoze.zodbconn
=================

A lbrary which allows `ZODB <http://zodb.org>`_ databases to be
constructed from URI specifications.

Read the latest documentation at `http://docs.repoze.org/zodbconn/
<http://docs.repoze.org/zodbconn/>`_.


