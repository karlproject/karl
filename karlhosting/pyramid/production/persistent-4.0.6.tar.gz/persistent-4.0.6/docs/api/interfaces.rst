:mod:`persistent.interfaces`
===================================

.. automodule:: persistent.interfaces

  .. autointerface:: IPersistent
     :members:
     :member-order: bysource

  .. autointerface:: IPersistentDataManager
     :members:
     :member-order: bysource

  .. autointerface:: IPickleCache
     :members:
     :member-order: bysource

