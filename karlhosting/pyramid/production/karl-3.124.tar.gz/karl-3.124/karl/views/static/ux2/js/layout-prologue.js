
/*
 * layout-prologue.js
 *
 * This must be an external script and cannot
 * be inline.
 *
 * This script can be concatenated and minified with the others.
 *
 */


// Release hold on ready event.
setTimeout(function() {
    jQuery.holdReady(false);
}, 10);

