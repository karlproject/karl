tinyMCE.addI18n('en.imagedrawer',{
image_desc: "Insert/edit image",
loading_title: 'Loading...'
});
