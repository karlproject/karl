.. _jslibs_api:

:mod:`jslibs` API
---------------------------

.. automodule:: jslibs

.. autofunction:: includeme

.. autofunction:: jslibs_macros_subscriber
