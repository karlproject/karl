example README
