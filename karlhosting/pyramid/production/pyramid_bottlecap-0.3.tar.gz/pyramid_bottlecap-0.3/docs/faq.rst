===
FAQ
===

- can use non-chameleon

- asset overloading

- not using macros on the main template, look at the first line!

- not using macros on your view template first line

- panel result wrapped in structure

- panel failure doesn't kill the entire page

- overriding static assets

- overriding panels

Popper
======

- quick panels and menus