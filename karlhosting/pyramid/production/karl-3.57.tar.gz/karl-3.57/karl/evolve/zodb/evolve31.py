
def evolve(site):
    print "This is a dummy evolve step for testing."
