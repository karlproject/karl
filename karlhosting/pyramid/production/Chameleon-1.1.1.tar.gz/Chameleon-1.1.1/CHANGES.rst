Changes
=======

1.1.1 (released 2010-01-26)
---------------------------

- Python 2.5 compatibility fixes (symptom: ``TypeError: default
  __new__ takes no parameters`` with the statement generating the
  error something like ``ast.Name("econtext", ast.Load())``).

1.1 (released 2010-01-26)
-------------------------

- Made all tests compatible with Python 2.4.

- Use the 2.5 AST for code transformation for compatibility with
  Google App Engine. The AST utilities required were copied from
  Genshi (license document included).

1.0.8 (released 2010-01-12)
---------------------------

- Use RPL license (http://repoze.org/license.html); include RPL and
  copyright notice in software.

1.0.7 (released 2010-01-07)
---------------------------

- Fixed encoding issue of translated attributes. [kobold]

- Fixed translation issue, that would prevent translation of tag
  contents with both named and unnamed subtags. [kobold]

- Fixed issue where messages could contain a double space. [kobold]

1.0.6 (released 2009-12-14)
---------------------------

- Fixed white space issue.

- Fixed character encoding issue.

- Fixed issue where macro extension would fail.

1.0.5 (released 2009-12-08)
---------------------------

- Fixed issue where the translation compiler would break on messages
  that contained the formatting character '%'.

- Fixed white space issue.

1.0.4 (released 2009-11-15)
---------------------------

- Fixed issue where the file-based template constructor did not accept
  the ``encoding`` parameter.

- Use more caution when falling back to dictionary lookup.

1.0.3 (released 2009-11-12)
---------------------------

- Fixed issue where traceback would contain erroneous debugging
  information. The source code is now taken directly from the
  traceback object.

- Include Python expression in syntax error exception message.

1.0.2 (released 2009-11-10)
---------------------------

- Really fixed ZCA import fallbacks.

1.0.1 (released 2009-11-04)
---------------------------

- Fixed ZCA import fallbacks.

1.0 (released 2009-11-01)
-------------------------

Features:

- HTML5 doctype is now supported.
