import unittest
from zope.testing.cleanup import cleanUp
from repoze.bfg import testing

class TestInvitationBoilerplate(unittest.TestCase):
    def setUp(self):
        cleanUp()

    def tearDown(self):
        cleanUp()

    def _getTargetClass(self):
        from fahamu.views.adapters import InvitationBoilerplate
        return InvitationBoilerplate

    def _makeOne(self, context, request):
        return self._getTargetClass()(context, request)

    def test_class_conforms_to_IInvitationBoilerplate(self):
        from zope.interface.verify import verifyClass
        from karl.views.interfaces import IInvitationBoilerplate
        verifyClass(IInvitationBoilerplate, self._getTargetClass())

    def test_terms_and_conditions(self):
        context = testing.DummyModel()
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        self.assertEqual(type(adapter.terms_and_conditions), unicode)
        self.assertTrue('terms' in adapter.terms_and_conditions)

    def test_privacy_statement(self):
        context = testing.DummyModel()
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        self.assertEqual(adapter.privacy_statement, '')


