``jslibs``
==============

``jslibs`` is a small package with few dependencies, aimed at providing
a high quality, curated set of Javascript packages for Pyramid
projects. In essence, a group of people have taken the work they are
already doing, then pushing it out to share with others. This work
includes use of `Juicer <https://github.com/cjohansen/juicer>`_ to
increase responsiveness of apps.


See `http://docs.pylonsproject.org/projects/jslibs/dev/
<http://docs.pylonsproject.org/projects/jslibs/dev/>`_
or ``docs/index.rst`` in this distribution for detailed
documentation.
