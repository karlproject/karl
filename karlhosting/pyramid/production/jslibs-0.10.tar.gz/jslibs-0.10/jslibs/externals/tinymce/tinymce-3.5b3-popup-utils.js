
/**
* TinyMCE popup resource utilities composition
* You can use this resource from a popup's html. Composition taken from media plugin.
*
* You have to use juicer to produce a minified resource based on this file
* You cannot use this file as a development resource
*
* 
* Popup resources:
*
*     @depends 3.5b3/jscripts/tiny_mce/tiny_mce_popup.js
*     @depends 3.5b3/jscripts/tiny_mce/utils/mctabs.js
*     @depends 3.5b3/jscripts/tiny_mce/utils/validate.js
*     @depends 3.5b3/jscripts/tiny_mce/utils/form_utils.js
*     @depends 3.5b3/jscripts/tiny_mce/utils/editable_selects.js
*
*/
