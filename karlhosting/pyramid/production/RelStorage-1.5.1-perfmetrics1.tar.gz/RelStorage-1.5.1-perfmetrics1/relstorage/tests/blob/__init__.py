"""This package contains test code copied from ZODB 3.9 with minor alterations.

It is especially useful for testing RelStorage + ZODB 3.8.
"""
