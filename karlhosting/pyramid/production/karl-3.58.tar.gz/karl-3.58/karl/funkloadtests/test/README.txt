So, I've been running these test by doing:

fl-run-test karltest.py

or 

fl-run-test test1.py


The funkloadcommands.py was where I was trying to poll together the "common" routines-make_community, etc.

Now the major tests will be in karltest.py or any other test routine we can develop.

-jbg
