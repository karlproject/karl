$(function() {
    $('.flash a.clear').click(function(e) {
        $(this).parent('.flash').hide();
        return false;
        });
    });

