# overall code version for ZODB state
VERSION = 10
NAME = 'OSI'
