
import unittest
from zope.testing.cleanup import cleanUp
from repoze.bfg import testing


class TestToolAddables(unittest.TestCase):
    def setUp(self):
        cleanUp()

    def tearDown(self):
        cleanUp()

    def _getTargetClass(self):
        from oxfam.views.adapters import ToolAddables
        return ToolAddables

    def _register(self):
        from repoze.lemonade.testing import registerListItem
        from karl.models.interfaces import IToolFactory
        tool_factory = DummyToolFactory(present=True)
        registerListItem(IToolFactory, tool_factory, 'blog')
        registerListItem(IToolFactory, tool_factory, 'wiki')
        registerListItem(IToolFactory, tool_factory, 'calendar')
        registerListItem(IToolFactory, tool_factory, 'files')
        registerListItem(IToolFactory, tool_factory, 'forums')
        registerListItem(IToolFactory, tool_factory, 'intranets')

    def _makeOne(self, context, request):
        return self._getTargetClass()(context, request)

    def test_class_conforms_to_IToolAddables(self):
        from zope.interface.verify import verifyClass
        from karl.views.interfaces import IToolAddables
        verifyClass(IToolAddables, self._getTargetClass())

    def test_tool_list_communities(self):
        from karl.content.interfaces import ICommunityFolder
        from zope.interface import alsoProvides
        self._register()
        context = testing.DummyModel()
        alsoProvides(context, ICommunityFolder)
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        self.assertEqual(len(adapter()), 4)

class TestLayoutProvider(unittest.TestCase):
    def setUp(self):
        cleanUp()

    def tearDown(self):
        cleanUp()

    def _getTargetClass(self):
        from oxfam.views.adapters import LayoutProvider
        return LayoutProvider

    def _makeOne(self, context, request):
        return self._getTargetClass()(context, request)

    def test_class_conforms_to_ILayoutProvider(self):
        from zope.interface.verify import verifyClass
        from karl.views.interfaces import ILayoutProvider
        verifyClass(ILayoutProvider, self._getTargetClass())

    def test_unknown_layout(self):
        # No interface on context, no default layout passed in
        context = testing.DummyModel()
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        layout = adapter()
        self.assertEqual(layout, None)

    def test_default_is_community(self):
        # No interface on context, pass in community as choice
        context = testing.DummyModel()
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        layout = adapter('community')
        self.assert_('community_layout.pt' in layout.filename)

    def test_default_is_generic(self):
        # No interface on context, pass in community as choice
        context = testing.DummyModel()
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        layout = adapter('generic')
        self.assert_('generic_layout.pt' in layout.filename)


class TestInvitationBoilerplate(unittest.TestCase):
    def setUp(self):
        cleanUp()

    def tearDown(self):
        cleanUp()

    def _getTargetClass(self):
        from oxfam.views.adapters import InvitationBoilerplate
        return InvitationBoilerplate

    def _makeOne(self, context, request):
        return self._getTargetClass()(context, request)

    def test_class_conforms_to_IInvitationBoilerplate(self):
        from zope.interface.verify import verifyClass
        from karl.views.interfaces import IInvitationBoilerplate
        verifyClass(IInvitationBoilerplate, self._getTargetClass())

    def test_terms_and_conditions(self):
        context = testing.DummyModel()
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        self.assertEqual(type(adapter.terms_and_conditions), unicode)
        self.assertTrue('terms' in adapter.terms_and_conditions)

    def test_privacy_statement(self):
        context = testing.DummyModel()
        request = testing.DummyRequest()
        adapter = self._makeOne(context, request)
        self.assertEqual(adapter.privacy_statement, '')


class TestOxfamFooter(unittest.TestCase):

    def _getTargetClass(self):
        from oxfam.views.adapters import OxfamFooter
        return OxfamFooter

    def _makeOne(self, context=None, request=None):
        if context is None:
            context = testing.DummyModel()
        if request is None:
            request = testing.DummyRequest()
        return self._getTargetClass()(context, request)

    def test_class_conforms_to_IFooter(self):
        from zope.interface.verify import verifyClass
        from karl.views.interfaces import IFooter
        verifyClass(IFooter, self._getTargetClass())

    def test_instance_conforms_to_IFooter(self):
        from zope.interface.verify import verifyObject
        from karl.views.interfaces import IFooter
        verifyObject(IFooter, self._makeOne())

    def test_it(self):
        renderer = testing.registerDummyRenderer('templates/footer.pt')
        footer = self._makeOne()
        api = object()
        response = footer(api)
        self.failUnless(renderer.api is api)

class TestCommunityFolderAddables(unittest.TestCase):
    def _makeOne(self, context=None, request=None):
        from oxfam.views.adapters import community_folder_addables
        if context is None:
            context = testing.DummyModel()
        if request is None:
            request = testing.DummyRequest()
        return community_folder_addables(context, request)

    def test_it(self):
        self.assertEquals(self._makeOne()(), [
            ('Add Folder', 'add_folder.html'),
            ('Add File', 'add_file.html')
            ])

class DummyToolFactory:
    def __init__(self, present=False):
        self.present = present

    def add(self, context, request):
        self.added = True

    def remove(self, context, request):
        self.removed = True

    def is_present(self, context, request):
        return self.present
