from karl.security.workflow import reset_security_workflow
from repoze.bfg.traversal import traverse
from repoze.bfg.traversal import model_path

exceptions = []

def evolve(context):
    for path in exceptions:
        d = traverse(context, path)
        ob = d['context']
        if model_path(ob) == path:
            if hasattr(ob, '__acl__'):
                ob.__custom_acl__ = ob.__acl__
    reset_security_workflow(context)
