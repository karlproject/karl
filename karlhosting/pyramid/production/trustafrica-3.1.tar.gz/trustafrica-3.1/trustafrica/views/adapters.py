from karl.utils import find_site
from karl.views.interfaces import IFooter
from repoze.bfg.chameleon_zpt import render_template
from zope.interface import implements


class TrustAfricaFooter(object):
    """ Multi-adapter for Six Feet Up KARL-specific page footer.
    """
    implements(IFooter)

    def __init__(self, context, request):
        self.context = context
        self.request = request

    def __call__(self, api):
        return render_template(
            'templates/footer.pt',
            api=api,
            )
