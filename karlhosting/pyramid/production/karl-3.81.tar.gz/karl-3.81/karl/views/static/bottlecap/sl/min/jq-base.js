/**
* Bottlecap jq-base resource composition
* You have to use juicer to produce a minified resource based on this file
* You cannot use this file as a development resource
*
*
* bc-core: 
*     @depends ../jquery-1.4.4.min.js
*     @depends ../jquery-ui-1.9m3.custom.min.js
*
*   
*
*/

