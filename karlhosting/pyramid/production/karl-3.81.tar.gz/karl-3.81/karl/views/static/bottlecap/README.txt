Location to place choice library versions of js/css, and sample interactions
with those libraries. This can grow into housing exampleware for several
widgets and other user interface interactions. It may also grow machinery for
generating minified combinations of css/js files. Generating python eggs is
also a possibility if we start to add widgets.
