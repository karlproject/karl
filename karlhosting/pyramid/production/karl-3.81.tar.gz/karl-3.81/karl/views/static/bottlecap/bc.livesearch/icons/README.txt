Icons provided by http://p.yusukekamiyamane.com/ 
with a Creative Commons Attribution 3.0 License
http://creativecommons.org/licenses/by/3.0/