
def evolve(root):
    root['offices']['calendar'].calendar_admin_email = 'globalstaffcalendar@list.soros.org'

