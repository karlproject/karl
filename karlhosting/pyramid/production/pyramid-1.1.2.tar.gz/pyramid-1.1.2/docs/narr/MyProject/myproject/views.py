def my_view(request):
    return {'project':'MyProject'}
