.. _session_module:

:mod:`pyramid.session`
---------------------------

.. automodule:: pyramid.session

  .. autofunction:: UnencryptedCookieSessionFactoryConfig

  .. autofunction:: signed_serialize

  .. autofunction:: signed_deserialize


