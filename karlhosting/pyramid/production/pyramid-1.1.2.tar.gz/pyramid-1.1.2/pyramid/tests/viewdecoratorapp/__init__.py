def includeme(config):
    config.scan('pyramid.tests.viewdecoratorapp')
    
