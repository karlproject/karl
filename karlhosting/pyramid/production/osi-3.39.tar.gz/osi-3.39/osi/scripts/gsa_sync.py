# Copyright (C) 2008-2009 Open Society Institute
#               Thomas Moroz: tmoroz@sorosny.org
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License Version 2 as published
# by the Free Software Foundation.  You may not use, modify or distribute
# this program under any other version of the GNU General Public License.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
""" Run GSA sync against a given data source.
"""
import codecs
import optparse
import sys
import transaction

from paste.deploy import loadapp
from pyramid.scripting import get_root

from karl.log import set_subsystem
from karl.scripting import get_default_config
from karl.scripting import run_daemon
from osi.sync.gsa_sync import GsaSync

import logging

log = logging.getLogger(__name__)


def main(args=sys.argv[1:]):
    logging.basicConfig()

    parser = optparse.OptionParser(description=__doc__,
                                   usage='%prog [options] url')
    parser.add_option('-C', '--config', dest='config',
        help='Path to configuration file (defaults to $CWD/etc/karl.ini)',
        metavar='FILE')
    parser.add_option('-u', '--user', dest='username',
        help='Username for basic HTTP auth.',
        metavar='USERNAME')
    parser.add_option('-p', '--password', dest='password',
        help='Password for basic HTTP auth.')
    parser.add_option('--dry-run', dest='dryrun',
        action='store_true', default=False,
        help="Don't actually commit the transaction")
    parser.add_option('--daemon', '-D', dest='daemon',
                      action='store_true', default=False,
                      help='Run in daemon mode.')
    parser.add_option('--interval', '-i', dest='interval', type='int',
                      default=300,
                      help='Interval, in seconds, between executions when in '
                           'daemon mode.')
    parser.add_option('--force-last-sync', '-s', dest='last_sync',
                      default=None,
                      help='Force the "last_gsa_sync" value used to determine '
                           'deltas from the GSA server')
    options, args = parser.parse_args(args)

    if not args:
        parser.error("Need url of datasource")

    url = args.pop(0)

    if args:
        parser.error("Too many parameters: %s" % repr(args))

    config = options.config
    if config is None:
        config = get_default_config()
    app = loadapp('config:%s' % config, name='karl')
    set_subsystem('gsa_sync')

    def run():
        closer = lambda: None
        try:
            root, closer = get_root(app)
            GsaSync(root,
                    url,
                    options.username,
                    options.password,
                    out=codecs.getwriter('UTF-8')(sys.stdout),
                    last_sync=options.last_sync,
                   )()
            root._p_jar.db().cacheMinimize() # Fixes memory leak
            if options.dryrun:
                transaction.abort()
            else:
                transaction.commit()
        except:
            transaction.abort()
            closer()
            raise
        else:
            closer()

    if options.daemon:
        run_daemon('gsa_sync', run, options.interval)
    else:
        run()


def config_parser(name, subparsers, **helpers):
    parser = subparsers.add_parser(
        name, help='Sync staff profiles and login to OSI GSA.')
    helpers['config_daemon_mode'](parser, 120)
    parser.add_argument('-u', '--user', help='Login username for GSA.')
    parser.add_argument('-p', '--password', help='Password for GSA.')
    parser.add_argument('inst', metavar='instance',
                        help='Instance name.  Must be an OSI instance.')
    parser.add_argument('url', help='URL of GSA datasource.')
    parser.set_defaults(func=main2, parser=parser, subsystem='gsa_sync',
                        only_one=True)


def main2(args):
    if not args.is_normal_mode(args.inst):
        log.info("Skipping %s: Running in maintenance mode." % args.inst)
        return

    site, closer = args.get_root(args.inst)
    set_subsystem('gsa_sync')
    settings = site._p_jar.root.instance_config
    if settings.get('package') != 'osi':
        args.parser.error("GSA Sync must be used with an OSI instance.")
    gsa_sync = GsaSync(site, args.url, args.user, args.password, args.out)
    gsa_sync()
    site._p_jar.db().cacheMinimize() # Attempt to fix memory leak
    transaction.commit()
    closer()
